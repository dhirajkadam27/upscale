import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

class Liked extends StatefulWidget {
  const Liked({super.key});

  @override
  State<Liked> createState() => _LikedState();
}

class _LikedState extends State<Liked> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width * 0.92,
          margin: EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  "https://miro.medium.com/max/750/1*ZJnECnO_uU2Ot-twtUyh8A.jpeg",
                  height: 70,
                  width: 130,
                  fit: BoxFit.fill,
                ),
              ),
              Container(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        child: Text(
                          "C++ Certificate Exam",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontFamily: 'Gentona-Medium',
                              fontSize: 15,
                              color: Colors.black),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        padding: EdgeInsets.only(top: 2, bottom: 2),
                        child: Text(
                          "Programming Language",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontFamily: 'Gentona-Book',
                              fontSize: 15,
                              color: Color(0xff484848)),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        child: Row(
                          children: const [
                            Text(
                              "₹3,499",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 19,
                                  color: Colors.black),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "₹3,499",
                              style: TextStyle(
                                  fontFamily: 'Gentona-Medium',
                                  fontSize: 15,
                                  color: Color(0xff484848)),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "70% off",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 15,
                                  color: Color(0xff8BCC27)),
                            ),
                          ],
                        ),
                      )
                    ]),
              )
            ],
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.92,
          margin: EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  "https://www.simplilearn.com/ice9/webinar_thum_image/JavaScript_Tutorial.jpg",
                  height: 70,
                  width: 130,
                  fit: BoxFit.fill,
                ),
              ),
              Container(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        child: Text(
                          "Javascript Certificate Exam",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontFamily: 'Gentona-Medium',
                              fontSize: 15,
                              color: Colors.black),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        padding: EdgeInsets.only(top: 2, bottom: 2),
                        child: Text(
                          "Programming Language",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontFamily: 'Gentona-Book',
                              fontSize: 15,
                              color: Color(0xff484848)),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        child: Row(
                          children: const [
                            Text(
                              "₹3,499",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 19,
                                  color: Colors.black),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "₹3,499",
                              style: TextStyle(
                                  fontFamily: 'Gentona-Medium',
                                  fontSize: 15,
                                  color: Color(0xff484848)),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "70% off",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 15,
                                  color: Color(0xff8BCC27)),
                            ),
                          ],
                        ),
                      )
                    ]),
              )
            ],
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.92,
          margin: EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  "https://www.mashupstack.com/assets/image/course-images/mashupstack_html.jpg?version=2.13",
                  height: 70,
                  width: 130,
                  fit: BoxFit.fill,
                ),
              ),
              Container(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        child: Text(
                          "HTML Certificate Exam",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontFamily: 'Gentona-Medium',
                              fontSize: 15,
                              color: Colors.black),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        padding: EdgeInsets.only(top: 2, bottom: 2),
                        child: Text(
                          "Programming Language",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontFamily: 'Gentona-Book',
                              fontSize: 15,
                              color: Color(0xff484848)),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.92 - 151,
                        margin: EdgeInsets.only(left: 10),
                        child: Row(
                          children: const [
                            Text(
                              "₹3,499",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 19,
                                  color: Colors.black),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "₹3,499",
                              style: TextStyle(
                                  fontFamily: 'Gentona-Medium',
                                  fontSize: 15,
                                  color: Color(0xff484848)),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "70% off",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 15,
                                  color: Color(0xff8BCC27)),
                            ),
                          ],
                        ),
                      )
                    ]),
              )
            ],
          ),
        ),
      ],
    );
  }
}
