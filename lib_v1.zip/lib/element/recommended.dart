import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

import '../screen/view.dart';

class FetchOffers extends StatefulWidget {
  const FetchOffers({super.key});

  @override
  State<FetchOffers> createState() => _FetchOffersState();
}

class _FetchOffersState extends State<FetchOffers> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: 220,
      // color: Colors.amber,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          InkWell(
            onTap: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => const View()));
            },
            child: Container(
              padding: const EdgeInsets.only(left: 20),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.network(
                        "https://www.mashupstack.com/assets/image/course-images/mashupstack_html.jpg?version=2.13",
                        height: 110,
                        width: 200,
                        fit: BoxFit.fill,
                      ),
                    ),
                    Container(
                      width: 200,
                      padding: const EdgeInsets.only(top: 10),
                      child: const Text(
                        "HTML Certificate Exam HTML Certificate Exam HTML Certificate Exam",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Medium',
                            fontSize: 15,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      width: 200,
                      padding: const EdgeInsets.only(top: 5),
                      child: const Text(
                        "Programming Language Programming Language Programming Language Programming Language",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Book',
                            fontSize: 15,
                            color: Color(0xff484848)),
                      ),
                    ),
                    Container(
                      width: 200,
                      padding: EdgeInsets.only(top: 5),
                      child: Row(
                        children: const [
                          Text(
                            "₹3,499",
                            style: TextStyle(
                                fontFamily: 'Gentona-SemiBold',
                                fontSize: 19,
                                color: Colors.black),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            "₹3,499",
                            style: TextStyle(
                                fontFamily: 'Gentona-Medium',
                                fontSize: 15,
                                color: Color(0xff484848)),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            "70% off",
                            style: TextStyle(
                                fontFamily: 'Gentona-SemiBold',
                                fontSize: 15,
                                color: Color(0xff8BCC27)),
                          ),
                        ],
                      ),
                    )
                  ]),
            ),
          ),
          Container(
            padding: const EdgeInsets.only(left: 20),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  "https://miro.medium.com/max/750/1*ZJnECnO_uU2Ot-twtUyh8A.jpeg",
                  height: 110,
                  width: 200,
                  fit: BoxFit.fill,
                ),
              ),
              Container(
                width: 200,
                padding: EdgeInsets.only(top: 10),
                child: Text(
                  "C++ Certificate Exam",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontFamily: 'Gentona-Medium',
                      fontSize: 15,
                      color: Colors.black),
                ),
              ),
              Container(
                width: 200,
                padding: EdgeInsets.only(top: 5),
                child: Text(
                  "Programming Language",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontFamily: 'Gentona-Book',
                      fontSize: 15,
                      color: Color(0xff484848)),
                ),
              ),
              Container(
                width: 200,
                padding: EdgeInsets.only(top: 5),
                child: Row(
                  children: const [
                    Text(
                      "₹3,499",
                      style: TextStyle(
                          fontFamily: 'Gentona-SemiBold',
                          fontSize: 19,
                          color: Colors.black),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "₹3,499",
                      style: TextStyle(
                          fontFamily: 'Gentona-Medium',
                          fontSize: 15,
                          color: Color(0xff484848)),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "70% off",
                      style: TextStyle(
                          fontFamily: 'Gentona-SemiBold',
                          fontSize: 15,
                          color: Color(0xff8BCC27)),
                    ),
                  ],
                ),
              )
            ]),
          ),
          Container(
            padding: const EdgeInsets.only(left: 20),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  "https://www.simplilearn.com/ice9/webinar_thum_image/JavaScript_Tutorial.jpg",
                  height: 110,
                  width: 200,
                  fit: BoxFit.fill,
                ),
              ),
              Container(
                width: 200,
                padding: const EdgeInsets.only(top: 10),
                child: const Text(
                  "Javascript Certificate Exam",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontFamily: 'Gentona-Medium',
                      fontSize: 15,
                      color: Colors.black),
                ),
              ),
              Container(
                width: 200,
                padding: const EdgeInsets.only(top: 5),
                child: const Text(
                  "Programming Language",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontFamily: 'Gentona-Book',
                      fontSize: 15,
                      color: Color(0xff484848)),
                ),
              ),
              Container(
                width: 200,
                padding: const EdgeInsets.only(top: 5),
                child: Row(
                  children: const [
                    Text(
                      "₹3,499",
                      style: TextStyle(
                          fontFamily: 'Gentona-SemiBold',
                          fontSize: 19,
                          color: Colors.black),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "₹3,499",
                      style: TextStyle(
                          fontFamily: 'Gentona-Medium',
                          fontSize: 15,
                          color: Color(0xff484848)),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "70% off",
                      style: TextStyle(
                          fontFamily: 'Gentona-SemiBold',
                          fontSize: 15,
                          color: Color(0xff8BCC27)),
                    ),
                  ],
                ),
              )
            ]),
          ),
          const SizedBox(
            width: 20,
          )
        ],
      ),
    );
  }
}
