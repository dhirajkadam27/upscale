import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Certficate extends StatefulWidget {
  const Certficate({super.key});

  @override
  State<Certficate> createState() => _CertficateState();
}

class _CertficateState extends State<Certficate> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
            child: ListView(
          children: [
            Container(
              width: MediaQuery.of(context).size.width * 0.92,
              margin: EdgeInsets.only(
                top: 15,
                bottom: 15,
                left: MediaQuery.of(context).size.width * 0.04,
                right: MediaQuery.of(context).size.width * 0.04,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const [
                  Text(
                    "Certficate",
                    style: TextStyle(
                        fontFamily: 'Gentona-SemiBold',
                        fontSize: 30,
                        color: Colors.black),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Container(
                  padding: EdgeInsets.only(top: 20),
                  child: Column(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.network(
                        "https://www.mashupstack.com/assets/image/course-images/mashupstack_html.jpg?version=2.13",
                        height: 200,
                        width: MediaQuery.of(context).size.width * 0.92,
                        fit: BoxFit.fill,
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 10),
                      child: const Text(
                        "HTML Certificate Exam HTML Certificate Exam HTML Certificate Exam",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Medium',
                            fontSize: 15,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 5),
                      child: const Text(
                        "Programming Language Programming Language Programming Language Programming Language",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Book',
                            fontSize: 15,
                            color: Color(0xff484848)),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: EdgeInsets.only(
                                top: 2, bottom: 2, left: 10, right: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Color(0xffFF842A).withOpacity(0.3),
                            ),
                            child: Text(
                              "Uncompleted",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 15,
                                  color: Color(0xffFF842A)),
                            ),
                          )
                        ],
                      ),
                    )
                  ]),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20),
                  child: Column(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.network(
                        "https://www.mashupstack.com/assets/image/course-images/mashupstack_html.jpg?version=2.13",
                        height: 200,
                        width: MediaQuery.of(context).size.width * 0.92,
                        fit: BoxFit.fill,
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 10),
                      child: const Text(
                        "HTML Certificate Exam HTML Certificate Exam HTML Certificate Exam",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Medium',
                            fontSize: 15,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 5),
                      child: const Text(
                        "Programming Language Programming Language Programming Language Programming Language",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Book',
                            fontSize: 15,
                            color: Color(0xff484848)),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: EdgeInsets.only(
                                top: 2, bottom: 2, left: 10, right: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Color(0xff8BCC27).withOpacity(0.3),
                            ),
                            child: Text(
                              "Completed",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 15,
                                  color: Color(0xff8BCC27)),
                            ),
                          )
                        ],
                      ),
                    )
                  ]),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20),
                  child: Column(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.network(
                        "https://www.mashupstack.com/assets/image/course-images/mashupstack_html.jpg?version=2.13",
                        height: 200,
                        width: MediaQuery.of(context).size.width * 0.92,
                        fit: BoxFit.fill,
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 10),
                      child: const Text(
                        "HTML Certificate Exam HTML Certificate Exam HTML Certificate Exam",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Medium',
                            fontSize: 15,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 5),
                      child: const Text(
                        "Programming Language Programming Language Programming Language Programming Language",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Book',
                            fontSize: 15,
                            color: Color(0xff484848)),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: EdgeInsets.only(
                                top: 2, bottom: 2, left: 10, right: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Color(0xffFF842A).withOpacity(0.3),
                            ),
                            child: Text(
                              "Uncompleted",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 15,
                                  color: Color(0xffFF842A)),
                            ),
                          )
                        ],
                      ),
                    )
                  ]),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20),
                  child: Column(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.network(
                        "https://www.mashupstack.com/assets/image/course-images/mashupstack_html.jpg?version=2.13",
                        height: 200,
                        width: MediaQuery.of(context).size.width * 0.92,
                        fit: BoxFit.fill,
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 10),
                      child: const Text(
                        "HTML Certificate Exam HTML Certificate Exam HTML Certificate Exam",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Medium',
                            fontSize: 15,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 5),
                      child: const Text(
                        "Programming Language Programming Language Programming Language Programming Language",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Gentona-Book',
                            fontSize: 15,
                            color: Color(0xff484848)),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: const EdgeInsets.only(top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: EdgeInsets.only(
                                top: 2, bottom: 2, left: 10, right: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Color(0xff8BCC27).withOpacity(0.3),
                            ),
                            child: Text(
                              "Completed",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 15,
                                  color: Color(0xff8BCC27)),
                            ),
                          )
                        ],
                      ),
                    )
                  ]),
                )
              ],
            ),
            const SizedBox(
              height: 100,
            ),
          ],
        )));
  }
}
