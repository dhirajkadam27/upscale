import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';

class Congrats extends StatefulWidget {
  const Congrats({super.key});

  @override
  State<Congrats> createState() => _CongratsState();
}

class _CongratsState extends State<Congrats> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
            child: ListView(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 100),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    "😍",
                    style: TextStyle(fontSize: 100),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    "27/30",
                    style: TextStyle(
                        color: Color(0xff484848),
                        fontFamily: 'Gentona-SemiBold',
                        fontSize: 15),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    "Congrats",
                    style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'Gentona-SemiBold',
                        fontSize: 25),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    "Well done!! Keep it up",
                    style: TextStyle(
                        color: Color(0xff484848),
                        fontFamily: 'Gentona-SemiBold',
                        fontSize: 15),
                  ),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.90,
              margin: EdgeInsets.only(
                  top: 30,
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05),
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Colors.grey),
                  borderRadius: BorderRadius.circular(10)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: SvgPicture.asset(
                  'assets/sample_cert.svg',
                  width: MediaQuery.of(context).size.width * 0.90,
                  fit: BoxFit.fill,
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.90,
              margin: EdgeInsets.only(
                  top: 40,
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05),
              height: 50,
              color: Color(0xff8BCC27),
              child: Center(
                child: Text(
                  "Download",
                  style: TextStyle(
                      color: Colors.black,
                      fontFamily: 'Gentona-SemiBold',
                      fontSize: 17),
                ),
              ),
            )
          ],
        )));
  }
}
