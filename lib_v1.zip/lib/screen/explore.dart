import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Explore extends StatefulWidget {
  const Explore({super.key});

  @override
  State<Explore> createState() => _ExploreState();
}

class _ExploreState extends State<Explore> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
            child: ListView(
          children: [
            Container(
              width: MediaQuery.of(context).size.width * 0.92,
              margin: EdgeInsets.only(
                top: 15,
                bottom: 15,
                left: MediaQuery.of(context).size.width * 0.04,
                right: MediaQuery.of(context).size.width * 0.04,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const [
                  Text(
                    "Explore",
                    style: TextStyle(
                        fontFamily: 'Gentona-SemiBold',
                        fontSize: 30,
                        color: Colors.black),
                  ),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.92,
              padding: const EdgeInsets.only(
                  top: 15, bottom: 15, left: 20, right: 20),
              margin: EdgeInsets.only(
                  top: 20,
                  left: MediaQuery.of(context).size.width * 0.04,
                  right: MediaQuery.of(context).size.width * 0.04),
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: const Color(0xffD0D0D0)),
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const [
                  Icon(
                    Icons.arrow_circle_right,
                    size: 20,
                    color: Color(0xff7AB51F),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Programming Language",
                    style: TextStyle(
                        fontFamily: 'Gentona-Book',
                        fontSize: 15,
                        color: Color(0xff585858)),
                  ),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.92,
              padding: const EdgeInsets.only(
                  top: 15, bottom: 15, left: 20, right: 20),
              margin: EdgeInsets.only(
                  top: 20,
                  left: MediaQuery.of(context).size.width * 0.04,
                  right: MediaQuery.of(context).size.width * 0.04),
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: const Color(0xffD0D0D0)),
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const [
                  Icon(
                    Icons.arrow_circle_right,
                    size: 20,
                    color: Color(0xff7AB51F),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Application Development",
                    style: TextStyle(
                        fontFamily: 'Gentona-Book',
                        fontSize: 15,
                        color: Color(0xff585858)),
                  ),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.92,
              padding: const EdgeInsets.only(
                  top: 15, bottom: 15, left: 20, right: 20),
              margin: EdgeInsets.only(
                  top: 20,
                  left: MediaQuery.of(context).size.width * 0.04,
                  right: MediaQuery.of(context).size.width * 0.04),
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: const Color(0xffD0D0D0)),
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const [
                  Icon(
                    Icons.arrow_circle_right,
                    size: 20,
                    color: Color(0xff7AB51F),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Database",
                    style: TextStyle(
                        fontFamily: 'Gentona-Book',
                        fontSize: 15,
                        color: Color(0xff585858)),
                  ),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.92,
              padding: const EdgeInsets.only(
                  top: 15, bottom: 15, left: 20, right: 20),
              margin: EdgeInsets.only(
                  top: 20,
                  left: MediaQuery.of(context).size.width * 0.04,
                  right: MediaQuery.of(context).size.width * 0.04),
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: const Color(0xffD0D0D0)),
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const [
                  Icon(
                    Icons.arrow_circle_right,
                    size: 20,
                    color: Color(0xff7AB51F),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Backend",
                    style: TextStyle(
                        fontFamily: 'Gentona-Book',
                        fontSize: 15,
                        color: Color(0xff585858)),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 100,
            ),
          ],
        )));
  }
}
