import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:upscale_final/screen/name.dart';

import 'bottom_navigation.dart';

class GetStarted extends StatefulWidget {
  const GetStarted({super.key});

  @override
  State<GetStarted> createState() => _GetStartedState();
}

class _GetStartedState extends State<GetStarted> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
            child: SizedBox(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.60,
                color: const Color(0xffF3FFF0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(bottom: 100),
                      child: Text(
                        "upStart",
                        style: TextStyle(
                            fontFamily: 'Poppins-ExtraBold',
                            fontSize: 30,
                            color: Colors.black),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 50),
                      child: SvgPicture.asset(
                        'assets/getstarted.svg',
                        width: MediaQuery.of(context).size.width * 0.70,
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                  bottom: 0,
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.92,
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.04),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * 0.75,
                            padding: const EdgeInsets.only(bottom: 30),
                            child: const Text(
                              "Start your career journey here",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 30,
                                  color: Colors.black),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              FirebaseAuth.instance
                                  .authStateChanges()
                                  .listen((User? user) async {
                                if (user == null) {
                                  print('User is currently signed out!');
                                } else {
                                  await GoogleSignIn().disconnect();
                                  FirebaseAuth.instance.signOut();
                                }
                              });
                              Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          const Name()));
                            },
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.92,
                              padding: EdgeInsets.only(
                                  top: 10, bottom: 10, left: 20, right: 20),
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    "Continue with Email",
                                    style: TextStyle(
                                        fontFamily: 'Gentona-Medium',
                                        fontSize: 20,
                                        color: Colors.white),
                                  ),
                                  SvgPicture.asset(
                                    'assets/right_arrow.svg',
                                    width: 25,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(bottom: 30, top: 5),
                            child: const Text(
                              "By continuing, you agree that you have read and accept our T&Cs and Privacy Policy",
                              style: TextStyle(
                                  fontFamily: 'Gentona-Book',
                                  fontSize: 13,
                                  color: Color(0xff7B7B7B)),
                            ),
                          ),
                        ]),
                  ))
            ],
          ),
        )));
  }
}
