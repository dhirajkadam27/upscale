import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:upscale_final/screen/try_again.dart';

class MCQ extends StatefulWidget {
  const MCQ({super.key});

  @override
  State<MCQ> createState() => _MCQState();
}

class _MCQState extends State<MCQ> {
  final user = Hive.box('User');
  int initialPoint = 0;
  int length = 0;
  String img = "";

  late Future _userActivityLog;

  @override
  void initState() {
    super.initState();
    _userActivityLog = fetchMCQS();
  }

  Future fetchMCQS() async {
    try {
      final fetch =
          await http.get(Uri.parse('https://mydukanpe.com/api/public/mcq.php'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        length = response.length;
        print(response.length);
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
            child: Stack(
          children: [
            ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.20,
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                          size: 30,
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.25,
                        alignment: Alignment.center,
                        child: const Text(
                          "30:00",
                          style: TextStyle(
                              color: Colors.black,
                              fontFamily: 'Gentona-SemiBold',
                              fontSize: 15),
                        ),
                      ),
                      Container(
                          width: MediaQuery.of(context).size.width * 0.25,
                          alignment: Alignment.center,
                          child: InkWell(
                            onTap: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => const TryAgain()));
                            },
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.20,
                              height: 40,
                              color: Color(0xff92C83E),
                              child: const Center(
                                child: Text(
                                  "Submit",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Gentona-SemiBold',
                                      fontSize: 15),
                                ),
                              ),
                            ),
                          ))
                    ],
                  ),
                ),
                Container(
                  height: 30,
                  padding: const EdgeInsets.only(left: 10),
                  margin: const EdgeInsets.only(top: 20, bottom: 20),
                  child: FutureBuilder(
                    future: _userActivityLog,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return ListView.builder(
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: true,
                          itemCount: snapshot.data!.length,
                          itemBuilder: (BuildContext context, index) {
                            return InkWell(
                              onTap: () {
                                initialPoint = index;
                                setState(() {});
                              },
                              child: Container(
                                width: 30,
                                height: 30,
                                margin: const EdgeInsets.only(right: 10),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: (initialPoint == index)
                                      ? const Color(0xff92C83E)
                                      : snapshot.data[index]['select'] != ""
                                          ? const Color(0xff92C83E)
                                          : const Color(0xffDDDDDD),
                                ),
                                child: Center(
                                  child: snapshot.data[index]['select'] != ""
                                      ? const Icon(
                                          Icons.done,
                                          size: 20,
                                          color: Colors.black,
                                        )
                                      : Text(
                                          (index + 1).toString(),
                                          style: const TextStyle(
                                              color: Colors.black,
                                              fontFamily: 'Gentona-SemiBold',
                                              fontSize: 13),
                                        ),
                                ),
                              ),
                            );
                          },
                        );
                      }

                      return SizedBox(
                        height: 30,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [
                            Container(
                              width: 30,
                              height: 30,
                              margin: const EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xffDDDDDD),
                              ),
                            ),
                            Container(
                              width: 30,
                              height: 30,
                              margin: const EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xffDDDDDD),
                              ),
                            ),
                            Container(
                              width: 30,
                              height: 30,
                              margin: const EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xffDDDDDD),
                              ),
                            ),
                            Container(
                              width: 30,
                              height: 30,
                              margin: const EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xffDDDDDD),
                              ),
                            ),
                            Container(
                              width: 30,
                              height: 30,
                              margin: const EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xffDDDDDD),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                Container(
                  height: MediaQuery.of(context).size.height * 0.70,
                  child: FutureBuilder(
                    future: _userActivityLog,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return ListView.builder(
                          scrollDirection: Axis.vertical,
                          itemCount: 1,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, index) {
                            return Column(
                              children: [
                                Container(
                                  padding: EdgeInsets.only(
                                      top: 10,
                                      left: MediaQuery.of(context).size.width *
                                          0.05,
                                      right: MediaQuery.of(context).size.width *
                                          0.05),
                                  child: Text(
                                    snapshot.data[initialPoint]['que'],
                                    style: const TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Gentona-SemiBold',
                                        fontSize: 15),
                                  ),
                                ),
                                Padding(
                                    padding: EdgeInsets.only(
                                        top: 40,
                                        left:
                                            MediaQuery.of(context).size.width *
                                                0.05,
                                        right:
                                            MediaQuery.of(context).size.width *
                                                0.05),
                                    child: InkWell(
                                      onTap: () {
                                        if (snapshot.data[initialPoint]
                                                ['select'] ==
                                            1) {
                                          snapshot.data[initialPoint]
                                              ['select'] = "";
                                        } else {
                                          snapshot.data[initialPoint]
                                              ['select'] = 1;
                                        }
                                        setState(() {});
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.90,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: snapshot.data[initialPoint]
                                                        ['select'] ==
                                                    1
                                                ? const Color(0xff92C83E)
                                                : Color(0xffE9E9E9)),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                width: 40,
                                                height: 40,
                                                margin: const EdgeInsets.only(
                                                    left: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            100),
                                                    color: Colors.black),
                                                child: Center(
                                                  child: Text(
                                                    "A",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontFamily:
                                                            'Gentona-SemiBold',
                                                        fontSize: 15),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.60,
                                                padding: const EdgeInsets.only(
                                                    left: 10,
                                                    right: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                child: Text(
                                                  snapshot.data[initialPoint]
                                                      ['a'],
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily:
                                                          'Gentona-Medium',
                                                      fontSize: 15),
                                                ),
                                              ),
                                            ]),
                                      ),
                                    )),
                                Padding(
                                    padding: EdgeInsets.only(
                                        top: 20,
                                        left:
                                            MediaQuery.of(context).size.width *
                                                0.05,
                                        right:
                                            MediaQuery.of(context).size.width *
                                                0.05),
                                    child: InkWell(
                                      onTap: () {
                                        if (snapshot.data[initialPoint]
                                                ['select'] ==
                                            2) {
                                          snapshot.data[initialPoint]
                                              ['select'] = "";
                                        } else {
                                          snapshot.data[initialPoint]
                                              ['select'] = 2;
                                        }
                                        setState(() {});
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.90,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: snapshot.data[initialPoint]
                                                        ['select'] ==
                                                    2
                                                ? const Color(0xff92C83E)
                                                : Color(0xffE9E9E9)),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                width: 40,
                                                height: 40,
                                                margin: const EdgeInsets.only(
                                                    left: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            100),
                                                    color: Colors.black),
                                                child: Center(
                                                  child: Text(
                                                    "B",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontFamily:
                                                            'Gentona-SemiBold',
                                                        fontSize: 15),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.60,
                                                padding: const EdgeInsets.only(
                                                    left: 10,
                                                    right: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                child: Text(
                                                  snapshot.data[initialPoint]
                                                      ['b'],
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily:
                                                          'Gentona-Medium',
                                                      fontSize: 15),
                                                ),
                                              ),
                                            ]),
                                      ),
                                    )),
                                Padding(
                                    padding: EdgeInsets.only(
                                        top: 20,
                                        left:
                                            MediaQuery.of(context).size.width *
                                                0.05,
                                        right:
                                            MediaQuery.of(context).size.width *
                                                0.05),
                                    child: InkWell(
                                      onTap: () {
                                        if (snapshot.data[initialPoint]
                                                ['select'] ==
                                            3) {
                                          snapshot.data[initialPoint]
                                              ['select'] = "";
                                        } else {
                                          snapshot.data[initialPoint]
                                              ['select'] = 3;
                                        }
                                        setState(() {});
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.90,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: snapshot.data[initialPoint]
                                                        ['select'] ==
                                                    3
                                                ? const Color(0xff92C83E)
                                                : Color(0xffE9E9E9)),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                width: 40,
                                                height: 40,
                                                margin: const EdgeInsets.only(
                                                    left: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            100),
                                                    color: Colors.black),
                                                child: Center(
                                                  child: Text(
                                                    "C",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontFamily:
                                                            'Gentona-SemiBold',
                                                        fontSize: 15),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.60,
                                                padding: const EdgeInsets.only(
                                                    left: 10,
                                                    right: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                child: Text(
                                                  snapshot.data[initialPoint]
                                                      ['c'],
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily:
                                                          'Gentona-Medium',
                                                      fontSize: 15),
                                                ),
                                              ),
                                            ]),
                                      ),
                                    )),
                                Padding(
                                    padding: EdgeInsets.only(
                                        top: 20,
                                        left:
                                            MediaQuery.of(context).size.width *
                                                0.05,
                                        right:
                                            MediaQuery.of(context).size.width *
                                                0.05),
                                    child: InkWell(
                                      onTap: () {
                                        if (snapshot.data[initialPoint]
                                                ['select'] ==
                                            4) {
                                          snapshot.data[initialPoint]
                                              ['select'] = "";
                                        } else {
                                          snapshot.data[initialPoint]
                                              ['select'] = 4;
                                        }
                                        setState(() {});
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.90,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: snapshot.data[initialPoint]
                                                        ['select'] ==
                                                    4
                                                ? const Color(0xff92C83E)
                                                : Color(0xffE9E9E9)),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                width: 40,
                                                height: 40,
                                                margin: const EdgeInsets.only(
                                                    left: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            100),
                                                    color: Colors.black),
                                                child: Center(
                                                  child: Text(
                                                    "D",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontFamily:
                                                            'Gentona-SemiBold',
                                                        fontSize: 15),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.60,
                                                padding: const EdgeInsets.only(
                                                    left: 10,
                                                    right: 10,
                                                    top: 10,
                                                    bottom: 10),
                                                child: Text(
                                                  snapshot.data[initialPoint]
                                                      ['d'],
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily:
                                                          'Gentona-Medium',
                                                      fontSize: 15),
                                                ),
                                              ),
                                            ]),
                                      ),
                                    )),
                              ],
                            );
                          },
                        );
                      }

                      // By default, show a loading spinner.
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(
                                top: 40,
                                left: MediaQuery.of(context).size.width * 0.05,
                                right:
                                    MediaQuery.of(context).size.width * 0.05),
                            child: Container(
                              color: Colors.white,
                              width: MediaQuery.of(context).size.width,
                              height: 10,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: 5,
                                left: MediaQuery.of(context).size.width * 0.05,
                                right:
                                    MediaQuery.of(context).size.width * 0.05),
                            child: Container(
                              color: Colors.white,
                              width: MediaQuery.of(context).size.width * 0.50,
                              height: 10,
                            ),
                          ),
                          Padding(
                              padding: EdgeInsets.only(
                                  top: 40,
                                  left:
                                      MediaQuery.of(context).size.width * 0.05,
                                  right:
                                      MediaQuery.of(context).size.width * 0.05),
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.90,
                                height: 60,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(100),
                                    color: Colors.white.withOpacity(0.19)),
                                child: Row(children: [
                                  Container(
                                    width: 50,
                                    height: 50,
                                    margin: const EdgeInsets.only(left: 5),
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        color: const Color(0xff00020C)),
                                    child: const Center(
                                      child: Text(
                                        "A",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontFamily: 'Gentona-Medium',
                                            fontSize: 20),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10),
                                    child: Container(
                                      color: Colors.white,
                                      width: MediaQuery.of(context).size.width *
                                          0.50,
                                      height: 10,
                                    ),
                                  ),
                                ]),
                              )),
                          Padding(
                              padding: EdgeInsets.only(
                                  top: 20,
                                  left:
                                      MediaQuery.of(context).size.width * 0.05,
                                  right:
                                      MediaQuery.of(context).size.width * 0.05),
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.90,
                                height: 60,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(100),
                                    color: const Color(0xff8BCC27)),
                                child: Row(children: [
                                  Container(
                                    width: 50,
                                    height: 50,
                                    margin: const EdgeInsets.only(left: 5),
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        color: Colors.white),
                                    child: const Center(
                                      child: Text(
                                        "B",
                                        style: TextStyle(
                                            color: Color(0xff00020C),
                                            fontFamily: 'Gentona-Medium',
                                            fontSize: 20),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10),
                                    child: Container(
                                      color: Colors.white,
                                      width: MediaQuery.of(context).size.width *
                                          0.50,
                                      height: 10,
                                    ),
                                  ),
                                ]),
                              )),
                          Padding(
                              padding: EdgeInsets.only(
                                  top: 20,
                                  left:
                                      MediaQuery.of(context).size.width * 0.05,
                                  right:
                                      MediaQuery.of(context).size.width * 0.05),
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.90,
                                height: 60,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(100),
                                    color: Colors.white.withOpacity(0.19)),
                                child: Row(children: [
                                  Container(
                                    width: 50,
                                    height: 50,
                                    margin: const EdgeInsets.only(left: 5),
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        color: const Color(0xff00020C)),
                                    child: const Center(
                                      child: Text(
                                        "C",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontFamily: 'Gentona-Medium',
                                            fontSize: 20),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10),
                                    child: Container(
                                      color: Colors.white,
                                      width: MediaQuery.of(context).size.width *
                                          0.50,
                                      height: 10,
                                    ),
                                  ),
                                ]),
                              )),
                          Padding(
                              padding: EdgeInsets.only(
                                  top: 20,
                                  left:
                                      MediaQuery.of(context).size.width * 0.05,
                                  right:
                                      MediaQuery.of(context).size.width * 0.05),
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.90,
                                height: 60,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(100),
                                    color: Colors.white.withOpacity(0.19)),
                                child: Row(children: [
                                  Container(
                                    width: 50,
                                    height: 50,
                                    margin: const EdgeInsets.only(left: 5),
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        color: const Color(0xff00020C)),
                                    child: const Center(
                                      child: Text(
                                        "D",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontFamily: 'Gentona-Medium',
                                            fontSize: 20),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10),
                                    child: Container(
                                      color: Colors.white,
                                      width: MediaQuery.of(context).size.width *
                                          0.50,
                                      height: 10,
                                    ),
                                  ),
                                ]),
                              ))
                        ],
                      );
                    },
                  ),
                ),
                const SizedBox(
                  height: 100,
                ),
              ],
            ),
            Positioned(
                bottom: 0,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.only(bottom: 10),
                  decoration: const BoxDecoration(color: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      (initialPoint > 0)
                          ? InkWell(
                              onTap: () {
                                if (initialPoint > 0) {
                                  setState(() {
                                    initialPoint--;
                                  });
                                }
                              },
                              child: Container(
                                width: 100,
                                height: 40,
                                color: const Color(0xff8BCC27),
                                margin: const EdgeInsets.all(10),
                                child: const Center(
                                  child: Text(
                                    "Prev",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Gentona-Medium',
                                        fontSize: 15),
                                  ),
                                ),
                              ),
                            )
                          : const Text(""),
                      (initialPoint != length - 1)
                          ? InkWell(
                              onTap: () {
                                setState(() {
                                  initialPoint++;
                                });
                              },
                              child: Container(
                                width: 100,
                                height: 40,
                                color: const Color(0xff8BCC27),
                                margin: const EdgeInsets.all(10),
                                child: const Center(
                                  child: Text(
                                    "Next",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Gentona-Medium',
                                        fontSize: 15),
                                  ),
                                ),
                              ),
                            )
                          : const Text(""),
                    ],
                  ),
                ))
          ],
        )));
  }
}
