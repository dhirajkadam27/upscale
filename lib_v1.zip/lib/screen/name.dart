import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';

import 'bottom_navigation.dart';

class Name extends StatefulWidget {
  const Name({super.key});

  @override
  State<Name> createState() => _NameState();
}

class _NameState extends State<Name> {
  TextEditingController nameController = TextEditingController();
  final user = Hive.box('User');
  bool loader = true;
  bool theme = false;
  @override
  void initState() {
    super.initState();
    googleLogin();
  }

  googleLogin() async {
    print("googleLogin method Called");
    GoogleSignIn _googleSignIn = GoogleSignIn();
    try {
      var reslut = await _googleSignIn.signIn();
      if (reslut == null) {
        return;
      }

      final userData = await reslut.authentication;
      final credential = GoogleAuthProvider.credential(
          accessToken: userData.accessToken, idToken: userData.idToken);
      var finalResult =
          await FirebaseAuth.instance.signInWithCredential(credential);
      setState(() {
        // google_sign_completed = true;
        // email = reslut.email;R
        // photo = reslut.photoUrl!;
        loader = false;
        nameController.text = reslut.displayName!;
      });
      if (reslut.displayName == null) {
        // showerror(context, "Something went wrong");
      }
    } catch (error) {
      // showerror(context, "Something went wrong");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Padding(
              padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 80,
                  ),
                  Text(
                    "Log In",
                    style: TextStyle(
                        fontFamily: 'Gentona-SemiBold',
                        fontSize: 30,
                        color: Colors.black),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 40,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                              width: 1, color: const Color(0xffD0D0D0)),
                          color: Colors.white),
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: TextField(
                        controller: nameController,
                        style: const TextStyle(
                            fontFamily: 'Gentona-Book',
                            fontSize: 15,
                            color: Color(0xff585858)),
                        decoration: InputDecoration(
                            hintStyle: const TextStyle(
                                fontFamily: 'Gentona-Book',
                                fontSize: 15,
                                color: Color(0xff585858)),
                            border: InputBorder.none,
                            hintText: 'Enter Your Name',
                            fillColor:
                                theme ? Colors.white : const Color(0xff7A7A7A)),
                      )),
                  const SizedBox(
                    height: 30,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              const BottomNavigation()));
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.92,
                      padding: EdgeInsets.only(
                          top: 10, bottom: 10, left: 20, right: 20),
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "Continue",
                            style: TextStyle(
                                fontFamily: 'Gentona-Medium',
                                fontSize: 20,
                                color: Colors.white),
                          ),
                          SvgPicture.asset(
                            'assets/right_arrow.svg',
                            width: 25,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            loader
                ? Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: theme
                        ? const Color(0xff181A20).withOpacity(0.3)
                        : Colors.white.withOpacity(0.3),
                    child: const Center(
                        child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.black,
                      ),
                    )),
                  )
                : const Text(""),
          ],
        ));
  }
}
