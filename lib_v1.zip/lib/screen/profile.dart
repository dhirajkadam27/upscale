import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
            child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Dhiraj Kadam",
                    style: TextStyle(
                        fontFamily: 'Gentona-SemiBold',
                        fontSize: 30,
                        color: Colors.black),
                  ),
                  Container(
                    width: 70,
                    height: 70,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: const Color(0xff8BCC27)),
                    child: Center(
                        child: Icon(
                      Icons.person,
                      size: 50,
                    )),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 40),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Edit Profile",
                    style: TextStyle(
                        fontFamily: 'Gentona-Medium',
                        fontSize: 20,
                        color: Colors.black),
                  ),
                  Icon(
                    Icons.arrow_right,
                    size: 35,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Privacy Policy",
                    style: TextStyle(
                        fontFamily: 'Gentona-Medium',
                        fontSize: 20,
                        color: Colors.black),
                  ),
                  Icon(
                    Icons.arrow_right,
                    size: 35,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Terms and Conditions",
                    style: TextStyle(
                        fontFamily: 'Gentona-Medium',
                        fontSize: 20,
                        color: Colors.black),
                  ),
                  Icon(
                    Icons.arrow_right,
                    size: 35,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Logout",
                    style: TextStyle(
                        fontFamily: 'Gentona-Medium',
                        fontSize: 20,
                        color: Colors.black),
                  ),
                  Icon(
                    Icons.arrow_right,
                    size: 35,
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 100,
            ),
          ],
        )));
  }
}
