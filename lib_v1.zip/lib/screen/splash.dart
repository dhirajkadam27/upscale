import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:upscale_final/screen/bottom_navigation.dart';
import 'package:upscale_final/screen/get_started.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  final user = Hive.box('User');
  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 2), () async {
      if (user.get('user') == null) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => const GetStarted()));
      } else {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => const BottomNavigation()));
      }
    });
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return const Scaffold(
        backgroundColor: Color(0xffF3FFF0),
        body: SafeArea(
          child: Center(
            child: Text(
              "upScale",
              style: TextStyle(
                  fontFamily: 'Poppins-ExtraBold',
                  fontSize: 35,
                  color: Colors.black),
            ),
          ),
        ));
  }
}
