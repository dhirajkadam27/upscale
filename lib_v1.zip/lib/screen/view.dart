import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:upscale_final/screen/congrats.dart';
import 'package:upscale_final/screen/mcq.dart';
import 'package:upscale_final/screen/try_again.dart';

class View extends StatefulWidget {
  const View({super.key});

  @override
  State<View> createState() => _ViewState();
}

class _ViewState extends State<View> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 227, 255, 220),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
            child: Stack(
          children: [
            ListView(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(0),
                  child: Image.network(
                    "https://www.mashupstack.com/assets/image/course-images/mashupstack_html.jpg?version=2.13",
                    height: 200,
                    width: MediaQuery.of(context).size.width,
                    fit: BoxFit.fill,
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(top: 20, left: 10, right: 10),
                  child: Text(
                    "HTML Certificate Exam HTML Certificate Exam HTML Certificate Exam",
                    style: TextStyle(
                        fontFamily: 'Gentona-Medium',
                        fontSize: 18,
                        color: Colors.black),
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(top: 10, left: 10, right: 10),
                  child: Text(
                    "Programming Language Programming Language Programming Language Programming Language",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontFamily: 'Gentona-Book',
                        fontSize: 15,
                        color: Color(0xff484848)),
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(top: 10, left: 10, right: 10),
                  child: Row(
                    children: const [
                      Text(
                        "₹3,499",
                        style: TextStyle(
                            fontFamily: 'Gentona-SemiBold',
                            fontSize: 20,
                            color: Colors.black),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "₹3,499",
                        style: TextStyle(
                            fontFamily: 'Gentona-Medium',
                            fontSize: 15,
                            color: Color(0xff484848)),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "70% off",
                        style: TextStyle(
                            fontFamily: 'Gentona-SemiBold',
                            fontSize: 15,
                            color: Color(0xff8BCC27)),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.92,
                  margin: EdgeInsets.only(
                    top: 20,
                    bottom: 10,
                    left: 10,
                    right: 10,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      Text(
                        "About Course",
                        style: TextStyle(
                            fontFamily: 'Gentona-SemiBold',
                            fontSize: 20,
                            color: Colors.black),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Text(
                    "Programming Language Programming Language Programming Language Programming Language",
                    style: TextStyle(
                        fontFamily: 'Gentona-Book',
                        fontSize: 15,
                        color: Color(0xff484848)),
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.92,
                  margin: EdgeInsets.only(
                    top: 20,
                    bottom: 20,
                    left: 10,
                    right: 10,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      Text(
                        "Sample Certificate",
                        style: TextStyle(
                            fontFamily: 'Gentona-SemiBold',
                            fontSize: 20,
                            color: Colors.black),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.70,
                  margin: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width * 0.15,
                      right: MediaQuery.of(context).size.width * 0.15),
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.grey),
                      borderRadius: BorderRadius.circular(10)),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: SvgPicture.asset(
                      'assets/sample_cert.svg',
                      width: MediaQuery.of(context).size.width * 0.70,
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
                top: 10,
                left: 10,
                child: Container(
                  width: 70,
                  height: 30,
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(100)),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(
                        Icons.arrow_back_ios,
                        color: Colors.white,
                        size: 15,
                      ),
                      Text(
                        "back",
                        style: TextStyle(
                            fontFamily: 'Gentona-SemiBold',
                            fontSize: 15,
                            color: Colors.white),
                      )
                    ],
                  ),
                )),
            Positioned(
              bottom: 0,
              left: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 70,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    border:
                        Border(top: BorderSide(width: 1, color: Colors.grey))),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => const Congrats()));
                        },
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 40,
                          color: Color(0xff92C83E),
                          child: Center(
                            child: Text(
                              "Try For Free",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 16,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => const MCQ()));
                        },
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 40,
                          color: Colors.black,
                          child: Center(
                            child: Text(
                              "Buy Now",
                              style: TextStyle(
                                  fontFamily: 'Gentona-SemiBold',
                                  fontSize: 16,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      )
                    ]),
              ),
            ),
            const SizedBox(
              height: 100,
            ),
          ],
        )));
  }
}
