import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:upscale/home.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class Course extends StatefulWidget {
  const Course({super.key});

  @override
  State<Course> createState() => _CourseState();
}

class _CourseState extends State<Course> {
  late YoutubePlayerController _controller;
  bool startprecent = false;
  double percent = 0.0;

  @override
  void initState() {
    super.initState();
    _controller = YoutubePlayerController(
      initialVideoId: 'HVjjoMvutj4',
      flags: YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    Future.delayed(const Duration(seconds: 3), () async {
      if (startprecent) {
        if (percent <= 0.95) {
          setState(() {
            percent = percent + 0.05;
          });
        } else {
          setState(() {
            percent = 0.0;
          });
        }
      }
    });

    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: Colors.white,
      child: Stack(
        children: [
          ListView(
            children: [
              const SizedBox(
                height: 200,
              ),
              const Padding(
                padding: EdgeInsets.only(left: 20, top: 20),
                child: Text(
                  "HTML Basics",
                  style: TextStyle(
                      fontSize: 13,
                      fontFamily: 'SemiBold',
                      color: Color(0xff767676)),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(left: 20, top: 10),
                child: Text(
                  "C Programming",
                  style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.only(left: 10, right: 20, top: 30),
                child: const Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Text(
                    "Videos",
                    style: TextStyle(
                        fontSize: 15,
                        fontFamily: 'SemiBold',
                        color: Color(0xff202020)),
                  ),
                ),
              ),
              Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 10,
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Color(0xffE3E3E3),
                          width: 1.0,
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        startprecent = true;
                        percent = 0.0;
                        _controller.seekTo(const Duration(minutes: 0));
                      });
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.only(
                          left: 10, right: 20, top: 10, bottom: 10),
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Color(0xffE3E3E3),
                            width: 1.0,
                          ),
                        ),
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    'https://i.ytimg.com/vi/HVjjoMvutj4/maxresdefault.jpg',
                                    fit: BoxFit.fitWidth,
                                    width: 80,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text(
                                  "Introduction",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontFamily: 'SemiBold',
                                      color: Color(0xff202020)),
                                ),
                              ],
                            ),
                            const Duration(minutes: 0) <
                                    Duration(
                                        minutes: _controller
                                            .value.position.inMinutes)
                                ? const Icon(
                                    Icons.check_circle,
                                    color: Color(0xffFF4F4F),
                                    size: 25,
                                  )
                                : const Duration(minutes: 0) ==
                                        Duration(
                                            minutes: _controller
                                                .value.position.inMinutes)
                                    ? CircularPercentIndicator(
                                        radius: 16.0,
                                        lineWidth: 3.0,
                                        percent: percent,
                                        center: const Center(
                                          child: Icon(
                                            Icons.pause_circle_filled,
                                            color: Color(0xffFF4F4F),
                                            size: 25,
                                          ),
                                        ),
                                        progressColor: const Color(0xffFF4F4F),
                                      )
                                    : const Icon(
                                        Icons.play_circle_fill,
                                        color: Color(0xff555555),
                                        size: 25,
                                      ),
                          ]),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        startprecent = true;
                        percent = 0.0;
                        _controller.seekTo(const Duration(minutes: 1));
                      });
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.only(
                          left: 10, right: 20, top: 10, bottom: 10),
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Color(0xffE3E3E3),
                            width: 1.0,
                          ),
                        ),
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    'https://i.ytimg.com/vi/HVjjoMvutj4/maxresdefault.jpg',
                                    fit: BoxFit.fitWidth,
                                    width: 80,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text(
                                  "Introduction",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontFamily: 'SemiBold',
                                      color: Color(0xff202020)),
                                ),
                              ],
                            ),
                            const Duration(minutes: 1) <
                                    Duration(
                                        minutes: _controller
                                            .value.position.inMinutes)
                                ? const Icon(
                                    Icons.check_circle,
                                    color: Color(0xffFF4F4F),
                                    size: 25,
                                  )
                                : const Duration(minutes: 1) ==
                                        Duration(
                                            minutes: _controller
                                                .value.position.inMinutes)
                                    ? CircularPercentIndicator(
                                        radius: 16.0,
                                        lineWidth: 3.0,
                                        percent: percent,
                                        center: const Center(
                                          child: Icon(
                                            Icons.pause_circle_filled,
                                            color: Color(0xffFF4F4F),
                                            size: 25,
                                          ),
                                        ),
                                        progressColor: const Color(0xffFF4F4F),
                                      )
                                    : const Icon(
                                        Icons.play_circle_fill,
                                        color: Color(0xff555555),
                                        size: 25,
                                      ),
                          ]),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        startprecent = true;
                        percent = 0.0;
                        _controller.seekTo(const Duration(minutes: 2));
                      });
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.only(
                          left: 10, right: 20, top: 10, bottom: 10),
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Color(0xffE3E3E3),
                            width: 1.0,
                          ),
                        ),
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    'https://i.ytimg.com/vi/HVjjoMvutj4/maxresdefault.jpg',
                                    fit: BoxFit.fitWidth,
                                    width: 80,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text(
                                  "Introduction",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontFamily: 'SemiBold',
                                      color: Color(0xff202020)),
                                ),
                              ],
                            ),
                            const Duration(minutes: 2) <
                                    Duration(
                                        minutes: _controller
                                            .value.position.inMinutes)
                                ? const Icon(
                                    Icons.check_circle,
                                    color: Color(0xffFF4F4F),
                                    size: 25,
                                  )
                                : const Duration(minutes: 2) ==
                                        Duration(
                                            minutes: _controller
                                                .value.position.inMinutes)
                                    ? CircularPercentIndicator(
                                        radius: 16.0,
                                        lineWidth: 3.0,
                                        percent: percent,
                                        center: const Center(
                                          child: Icon(
                                            Icons.pause_circle_filled,
                                            color: Color(0xffFF4F4F),
                                            size: 25,
                                          ),
                                        ),
                                        progressColor: const Color(0xffFF4F4F),
                                      )
                                    : const Icon(
                                        Icons.play_circle_fill,
                                        color: Color(0xff555555),
                                        size: 25,
                                      ),
                          ]),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        startprecent = true;
                        percent = 0.0;
                        _controller.seekTo(const Duration(minutes: 3));
                      });
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.only(
                          left: 10, right: 20, top: 10, bottom: 10),
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Color(0xffE3E3E3),
                            width: 1.0,
                          ),
                        ),
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    'https://i.ytimg.com/vi/HVjjoMvutj4/maxresdefault.jpg',
                                    fit: BoxFit.fitWidth,
                                    width: 80,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text(
                                  "Introduction",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontFamily: 'SemiBold',
                                      color: Color(0xff202020)),
                                ),
                              ],
                            ),
                            const Duration(minutes: 3) <
                                    Duration(
                                        minutes: _controller
                                            .value.position.inMinutes)
                                ? const Icon(
                                    Icons.check_circle,
                                    color: Color(0xffFF4F4F),
                                    size: 25,
                                  )
                                : const Duration(minutes: 3) ==
                                        Duration(
                                            minutes: _controller
                                                .value.position.inMinutes)
                                    ? CircularPercentIndicator(
                                        radius: 16.0,
                                        lineWidth: 3.0,
                                        percent: percent,
                                        center: const Center(
                                          child: Icon(
                                            Icons.pause_circle_filled,
                                            color: Color(0xffFF4F4F),
                                            size: 25,
                                          ),
                                        ),
                                        progressColor: const Color(0xffFF4F4F),
                                      )
                                    : const Icon(
                                        Icons.play_circle_fill,
                                        color: Color(0xff555555),
                                        size: 25,
                                      ),
                          ]),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        startprecent = true;
                        percent = 0.0;
                        _controller.seekTo(const Duration(minutes: 4));
                      });
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.only(
                          left: 10, right: 20, top: 10, bottom: 10),
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Color(0xffE3E3E3),
                            width: 1.0,
                          ),
                        ),
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    'https://i.ytimg.com/vi/HVjjoMvutj4/maxresdefault.jpg',
                                    fit: BoxFit.fitWidth,
                                    width: 80,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text(
                                  "Introduction",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontFamily: 'SemiBold',
                                      color: Color(0xff202020)),
                                ),
                              ],
                            ),
                            const Duration(minutes: 4) <
                                    Duration(
                                        minutes: _controller
                                            .value.position.inMinutes)
                                ? const Icon(
                                    Icons.check_circle,
                                    color: Color(0xffFF4F4F),
                                    size: 25,
                                  )
                                : const Duration(minutes: 4) ==
                                        Duration(
                                            minutes: _controller
                                                .value.position.inMinutes)
                                    ? CircularPercentIndicator(
                                        radius: 16.0,
                                        lineWidth: 3.0,
                                        percent: percent,
                                        center: const Center(
                                          child: Icon(
                                            Icons.pause_circle_filled,
                                            color: Color(0xffFF4F4F),
                                            size: 25,
                                          ),
                                        ),
                                        progressColor: const Color(0xffFF4F4F),
                                      )
                                    : const Icon(
                                        Icons.play_circle_fill,
                                        color: Color(0xff555555),
                                        size: 25,
                                      ),
                          ]),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 100,
              )
            ],
          ),
          YoutubePlayer(
            controller: _controller,
            showVideoProgressIndicator: true,
            progressIndicatorColor: Colors.amber,
            progressColors: const ProgressBarColors(
              playedColor: Colors.amber,
              handleColor: Colors.amberAccent,
            ),
            onReady: () {
              setState(() {
                startprecent = true;
                percent = 0.0;
              });
              _controller.addListener(() {});
            },
          ),
        ],
      ),
    )));
  }
}
