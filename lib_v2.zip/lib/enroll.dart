import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale/course.dart';
import 'package:upscale/home.dart';

class Enroll extends StatefulWidget {
  const Enroll({super.key});

  @override
  State<Enroll> createState() => _EnrollState();
}

class _EnrollState extends State<Enroll> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: Colors.white,
      child: Stack(
        children: [
          ListView(
            children: [
              Stack(
                children: [
                  Image.network(
                    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzb-tHLTy_x3v4ZB57K-ufNqxXyHPT3AARmQ&usqp=CAU',
                    fit: BoxFit.fitWidth,
                    width: MediaQuery.of(context).size.width,
                  ),
                  Positioned(
                    top: 10,
                    left: 10,
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                      },
                      child: ClipRRect(
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                          child: Container(
                            padding: const EdgeInsets.only(
                                left: 5, right: 15, top: 2, bottom: 2),
                            decoration: BoxDecoration(
                                color: const Color(0xff000000).withOpacity(0.5),
                                borderRadius: BorderRadius.circular(100)),
                            child: Row(children: const [
                              Icon(
                                Icons.keyboard_arrow_left,
                                color: Colors.white,
                                size: 25,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                    fontFamily: 'SemiBold',
                                    fontSize: 15,
                                    color: Colors.white),
                              )
                            ]),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 10,
                    right: 10,
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const Course()));
                      },
                      child: ClipRRect(
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                          child: Container(
                            padding: const EdgeInsets.only(
                                left: 5, right: 15, top: 2, bottom: 2),
                            decoration: BoxDecoration(
                                color: const Color(0xff000000).withOpacity(0.5),
                                borderRadius: BorderRadius.circular(100)),
                            child: Row(children: const [
                              Icon(
                                Icons.play_circle_fill,
                                color: Colors.white,
                                size: 25,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                "Preview",
                                style: TextStyle(
                                    fontFamily: 'SemiBold',
                                    fontSize: 15,
                                    color: Colors.white),
                              )
                            ]),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
              const Padding(
                padding: EdgeInsets.only(left: 20, top: 20),
                child: Text(
                  "C Programming",
                  style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.only(left: 10, right: 20, top: 30),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Padding(
                        padding: EdgeInsets.only(bottom: 10),
                        child: Text(
                          "Course Content",
                          style: TextStyle(
                              fontSize: 15,
                              fontFamily: 'SemiBold',
                              color: Color(0xff202020)),
                        ),
                      ),
                      Icon(
                        Icons.keyboard_arrow_down,
                        color: Color(0xff202020),
                        size: 25,
                      )
                    ]),
              ),
              Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 10,
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Color(0xffE3E3E3),
                          width: 1.0,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    padding: const EdgeInsets.only(left: 10, right: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Color(0xffE3E3E3),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: const [
                              Icon(
                                Icons.play_circle_fill,
                                color: Color(0xff767676),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                "Introduction",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: 'SemiBold',
                                    color: Color(0xff202020)),
                              ),
                            ],
                          ),
                          const Text(
                            "2 min",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'SemiBold',
                                color: Color(0xff767676)),
                          ),
                        ]),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    padding: const EdgeInsets.only(left: 10, right: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Color(0xffE3E3E3),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: const [
                              Icon(
                                Icons.play_circle_fill,
                                color: Color(0xff767676),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                "HTML Basics",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: 'SemiBold',
                                    color: Color(0xff202020)),
                              ),
                            ],
                          ),
                          const Text(
                            "2 min",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'SemiBold',
                                color: Color(0xff767676)),
                          ),
                        ]),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    padding: const EdgeInsets.only(left: 10, right: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Color(0xffE3E3E3),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: const [
                              Icon(
                                Icons.play_circle_fill,
                                color: Color(0xff767676),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                "CSS Basics",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: 'SemiBold',
                                    color: Color(0xff202020)),
                              ),
                            ],
                          ),
                          const Text(
                            "2 min",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'SemiBold',
                                color: Color(0xff767676)),
                          ),
                        ]),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    padding: const EdgeInsets.only(left: 10, right: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Color(0xffE3E3E3),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: const [
                              Icon(
                                Icons.play_circle_fill,
                                color: Color(0xff767676),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                "JS Basics",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: 'SemiBold',
                                    color: Color(0xff202020)),
                              ),
                            ],
                          ),
                          const Text(
                            "2 min",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'SemiBold',
                                color: Color(0xff767676)),
                          ),
                        ]),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    padding: const EdgeInsets.only(left: 10, right: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Color(0xffE3E3E3),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: const [
                              Icon(
                                Icons.assignment,
                                color: Color(0xff767676),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                "Test",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: 'SemiBold',
                                    color: Color(0xff202020)),
                              ),
                            ],
                          ),
                          const Text(
                            "2 min",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'SemiBold',
                                color: Color(0xff767676)),
                          ),
                        ]),
                  ),
                ],
              ),
              const Padding(
                padding: EdgeInsets.only(top: 40, left: 10),
                child: Text(
                  "Web Development",
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'SemiBold',
                      color: Color(0xff202020)),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 10, right: 10, left: 10),
                child: Text(
                  "Our course will explain the concept of home automation which is growing at great speed. Beginning from scratch of embedded systems & its concepts, while using these concepts to control the home appliances by an assignment approach that is followed in this course. You will also have the opportunity to create your own MIT app with step-by-step explanations that come along with this course. Explore the abilities of esp32 while making way to the project - home automation & enter the Embedded industry that has 12 Lakh+ job opportunities.",
                  style: TextStyle(
                      fontSize: 13,
                      fontFamily: 'Medium',
                      color: Color(0xff767676)),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    decoration: BoxDecoration(
                        color: const Color(0xff2B2B2B),
                        borderRadius: BorderRadius.circular(5)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Padding(
                            padding: EdgeInsets.only(top: 10, left: 10),
                            child: Text(
                              "Duration",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  color: Color(0xffA6A6A6),
                                  fontSize: 10),
                            ),
                          ),
                          Padding(
                            padding:
                                EdgeInsets.only(top: 5, left: 10, bottom: 10),
                            child: Text(
                              "5 Hours",
                              style: TextStyle(
                                  fontFamily: 'Bold',
                                  color: Colors.white,
                                  fontSize: 17),
                            ),
                          ),
                        ]),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    decoration: BoxDecoration(
                        color: const Color(0xff2B2B2B),
                        borderRadius: BorderRadius.circular(5)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Padding(
                            padding: EdgeInsets.only(top: 10, left: 10),
                            child: Text(
                              "Language",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  color: Color(0xffA6A6A6),
                                  fontSize: 10),
                            ),
                          ),
                          Padding(
                            padding:
                                EdgeInsets.only(top: 5, left: 10, bottom: 10),
                            child: Text(
                              "Hindi",
                              style: TextStyle(
                                  fontFamily: 'Bold',
                                  color: Colors.white,
                                  fontSize: 17),
                            ),
                          ),
                        ]),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    decoration: BoxDecoration(
                        color: const Color(0xff2B2B2B),
                        borderRadius: BorderRadius.circular(5)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Padding(
                            padding: EdgeInsets.only(top: 10, left: 10),
                            child: Text(
                              "Enrolled",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  color: Color(0xffA6A6A6),
                                  fontSize: 10),
                            ),
                          ),
                          Padding(
                            padding:
                                EdgeInsets.only(top: 5, left: 10, bottom: 10),
                            child: Text(
                              "15,000",
                              style: TextStyle(
                                  fontFamily: 'Bold',
                                  color: Colors.white,
                                  fontSize: 17),
                            ),
                          ),
                        ]),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    decoration: BoxDecoration(
                        color: const Color(0xff2B2B2B),
                        borderRadius: BorderRadius.circular(5)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(top: 10, left: 10),
                            child: Text(
                              "Price",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  color: Color(0xffA6A6A6),
                                  fontSize: 10),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: const [
                              Padding(
                                padding: EdgeInsets.only(
                                    top: 5, left: 10, bottom: 10),
                                child: Text(
                                  "₹200/-",
                                  style: TextStyle(
                                      fontFamily: 'Bold',
                                      color: Color(0xffFF4F4F),
                                      fontSize: 16),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    top: 5, left: 10, bottom: 10),
                                child: Text(
                                  " ₹400/- ",
                                  style: TextStyle(
                                      decoration: TextDecoration.lineThrough,
                                      decorationColor: Color(0xffFF4F4F),
                                      decorationThickness: 2,
                                      fontFamily: 'Bold',
                                      color: Colors.white,
                                      fontSize: 12),
                                ),
                              ),
                            ],
                          )
                        ]),
                  ),
                ],
              ),
              const Padding(
                padding: EdgeInsets.only(top: 40, left: 10),
                child: Text(
                  "Certificate Sample",
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'SemiBold',
                      color: Color(0xff202020)),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Center(
                child: Container(
                  margin: const EdgeInsets.all(40),
                  width: double.infinity,
                  child: CupertinoContextMenu(
                    actions: [
                      CupertinoContextMenuAction(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        isDestructiveAction: true,
                        child: const Text("View More"),
                      )
                    ],
                    previewBuilder: (context, animation, child) {
                      return const Text("data");
                    },
                    child: Image.asset(
                      "assets/certificate.png",
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 100,
              )
            ],
          ),
          Positioned(
            bottom: 20,
            left: MediaQuery.of(context).size.width * 0.05,
            child: InkWell(
              onTap: () {
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => const Home()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width * 0.90,
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: const Color(0xffFF4F4F)),
                child: const Text(
                  "Buy at ₹ 200 /- only",
                  style: TextStyle(
                    fontSize: 15,
                    fontFamily: 'Bold',
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    )));
  }
}
