import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale/privacy_policy.dart';

class GetStarted extends StatefulWidget {
  const GetStarted({super.key});

  @override
  State<GetStarted> createState() => _GetStartedState();
}

class _GetStartedState extends State<GetStarted> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xffFF4F4F),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));

    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: const Color(0xffFF4F4F),
      child: Column(
        children: [
          const SizedBox(
            height: 30,
          ),
          const Text(
            "Upscale",
            style: TextStyle(
                fontSize: 30, fontFamily: 'ExtraBold', color: Colors.white),
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.30,
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.90,
            child: const Text(
              "Start your career Journey here.....",
              style: TextStyle(
                  fontSize: 40, fontFamily: 'ExtraBold', color: Colors.white),
            ),
          ),
          const SizedBox(
            height: 50,
          ),
          InkWell(
            onTap: () {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (BuildContext context) => const PrivacyPolicy()));
            },
            child: Container(
              width: MediaQuery.of(context).size.width * 0.90,
              height: 50,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5), color: Colors.white),
              child: const Text(
                "Agree and continue",
                style: TextStyle(
                  fontSize: 15,
                  fontFamily: 'Bold',
                  color: Color(0xffFF4F4F),
                ),
              ),
            ),
          ),
        ],
      ),
    )));
  }
}
