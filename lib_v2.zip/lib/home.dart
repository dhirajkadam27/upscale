import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale/enroll.dart';
import 'package:http/http.dart' as http;

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class Welcome {
  Welcome({
    required this.img,
    required this.title,
    required this.duration,
    required this.language,
    required this.enrolled,
    required this.mrp,
    required this.discount,
  });

  String img;
  String title;
  String duration;
  String language;
  int enrolled;
  int mrp;
  int discount;

  factory Welcome.fromJson(Map<String, dynamic> json) => Welcome(
        img: json["img"],
        title: json["title"],
        duration: json["duration"],
        language: json["language"],
        enrolled: json["enrolled"],
        mrp: json["mrp"],
        discount: json["discount"],
      );

  Map<String, dynamic> toJson() => {
        "img": img,
        "title": title,
        "duration": duration,
        "language": language,
        "enrolled": enrolled,
        "mrp": mrp,
        "discount": discount,
      };
}

class _HomeState extends State<Home> {
  @override
  void initState() {
    super.initState();
  }

  Future _fetchData(id) async {
    try {
      final data = await Future.wait({
        http.get(Uri.parse("https://mydukanpe.com/upscale/banner.php")),
        http.get(
            Uri.parse("https://mydukanpe.com/upscale/popular_courses.php")),
        http.get(Uri.parse("https://mydukanpe.com/upscale/courses.php")),
      });

      if (data[0].statusCode == 200 &&
          data[1].statusCode == 200 &&
          data[2].statusCode == 200) {
        if (id == 0) {
          List<String> response = jsonDecode_1(data[0].body);
          return response;
        } else if (id == 1) {
          List<Welcome> response = welcomeFromJson(data[1].body);
          print(response[0].img);
          return response;
        } else if (id == 2) {
          List<String> response = jsonDecode_1(data[2].body);
          print(response[0]);
          return response;
        }
      } else {}
    } on SocketException catch (_) {}
  }

  List<String> jsonDecode_1(String str) =>
      List<String>.from(json.decode(str).map((x) => x));

  List<Welcome> welcomeFromJson(String str) =>
      List<Welcome>.from(json.decode(str).map((x) => Welcome.fromJson(x)));

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: Colors.white,
      child: Stack(
        children: [
          ListView(
            children: [
              const SizedBox(
                height: 30,
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Upscale",
                  style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'ExtraBold',
                      color: Color(0xffFF4F4F)),
                ),
              ),
              const SizedBox(
                height: 40,
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.90,
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Good Morning",
                  style: TextStyle(
                      fontSize: 12,
                      fontFamily: 'ExtraBold',
                      color: Color(0xff767676)),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.90,
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Dhiraj Kadam",
                  style: TextStyle(
                      fontSize: 25,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              Container(
                margin: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(
                    'https://s3.ap-south-1.amazonaws.com/guvi-2.0/banner/x_mas_banner_2_(V1).webp',
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 150,
                    fit: BoxFit.fill,
                  ),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              InkWell(
                onTap: () {
                  // Navigator.of(context).push(MaterialPageRoute(
                  //     builder: (context) => DTHNum()));
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.90,
                  height: 50,
                  margin: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width * 0.05,
                      right: MediaQuery.of(context).size.width * 0.05),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: const Color(0xffE6E6E6)),
                  child: Row(
                    children: const [
                      SizedBox(
                        width: 20,
                      ),
                      Icon(
                        Icons.search_rounded,
                        color: Color(0xff555555),
                        size: 25,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Explore courses and features",
                        style: TextStyle(
                          fontSize: 13,
                          fontFamily: 'Bold',
                          color: Color(0xff555555),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Popular Courses",
                  style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              FutureBuilder(
                future: _fetchData(1),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data!.isEmpty) {
                      return SizedBox(
                        width: MediaQuery.of(context).size.width,
                        height: 100,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: const [
                            Text("No Transactions Yet"),
                          ],
                        ),
                      );
                    } else {
                      return SizedBox(
                        width: MediaQuery.of(context).size.width,
                        height: 300,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: snapshot.data!.length,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, index) {
                            return InkWell(
                              onTap: () {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (context) => const Enroll()));
                              },
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.80,
                                margin: const EdgeInsets.only(left: 20),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border.all(
                                        width: 1,
                                        color: const Color(0xffC8C8C8))),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Center(
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(5),
                                        child: Image.network(
                                          snapshot.data![index].img,
                                          fit: BoxFit.fill,
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.70,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(
                                        left:
                                            MediaQuery.of(context).size.width *
                                                0.05,
                                        right:
                                            MediaQuery.of(context).size.width *
                                                0.05,
                                      ),
                                      child: Text(
                                        snapshot.data![index].title,
                                        style: const TextStyle(
                                            fontSize: 13,
                                            fontFamily: 'Bold',
                                            color: Color(0xff202020)),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Row(
                                          children: [
                                            const Icon(
                                              Icons.access_time,
                                              color: Color(0xff767676),
                                              size: 15,
                                            ),
                                            const SizedBox(
                                              width: 2,
                                            ),
                                            Text(
                                              snapshot.data![index].duration,
                                              style: const TextStyle(
                                                  fontSize: 10,
                                                  fontFamily: 'SemiBold',
                                                  color: Color(0xff767676)),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            const Icon(
                                              Icons.language,
                                              color: Color(0xff767676),
                                              size: 15,
                                            ),
                                            const SizedBox(
                                              width: 2,
                                            ),
                                            Text(
                                              snapshot.data![index].language,
                                              style: const TextStyle(
                                                  fontSize: 10,
                                                  fontFamily: 'SemiBold',
                                                  color: Color(0xff767676)),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            const Icon(
                                              Icons.person_outline,
                                              color: Color(0xff767676),
                                              size: 15,
                                            ),
                                            const SizedBox(
                                              width: 2,
                                            ),
                                            Text(
                                              "${snapshot.data![index].enrolled} Enrolled",
                                              style: const TextStyle(
                                                  fontSize: 10,
                                                  fontFamily: 'SemiBold',
                                                  color: Color(0xff767676)),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            const SizedBox(
                                              width: 20,
                                            ),
                                            Text(
                                              "₹${(snapshot.data![index].mrp - snapshot.data![index].mrp * snapshot.data![index].discount / 100).toStringAsFixed(2)}/-",
                                              style: const TextStyle(
                                                fontSize: 15,
                                                fontFamily: 'SemiBold',
                                                color: Color(0xffFF4F4F),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 20,
                                            ),
                                            Text(
                                              " ₹${snapshot.data![index].mrp}/-",
                                              style: const TextStyle(
                                                  decoration: TextDecoration
                                                      .lineThrough,
                                                  decorationColor:
                                                      Color(0xffFF4F4F),
                                                  decorationThickness: 2,
                                                  fontSize: 15,
                                                  fontFamily: 'SemiBold',
                                                  color: Color(0xff767676)),
                                            ),
                                          ],
                                        ),
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.25,
                                          margin: const EdgeInsets.only(top: 3),
                                          child: ClipPath(
                                            clipper: DiscountClip(),
                                            child: Container(
                                              padding: const EdgeInsets.all(8),
                                              color: const Color(0xffFF4F4F),
                                              alignment: Alignment.center,
                                              child: Text(
                                                "${snapshot.data![index].discount}% OFF",
                                                style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    }
                  } else if (snapshot.hasError) {
                    return SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: 100,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Text("Something went wrong"),
                        ],
                      ),
                    );
                  }

                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 100,
                    child: const Center(
                        child: SizedBox(
                      width: 30,
                      height: 30,
                      child: CircularProgressIndicator(
                        color: Color(0xff00CE19),
                      ),
                    )),
                  );
                },
              ),
              const SizedBox(
                height: 30,
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Courses",
                  style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.90,
                height: 25,
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: Color(0xffE3E3E3),
                      width: 1.0,
                    ),
                  ),
                ),
              ),
              FutureBuilder(
                future: _fetchData(2),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data!.isEmpty) {
                      return SizedBox(
                        width: MediaQuery.of(context).size.width,
                        height: 100,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: const [
                            Text("No Transactions Yet"),
                          ],
                        ),
                      );
                    } else {
                      return ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        scrollDirection: Axis.vertical,
                        itemCount: snapshot.data!.length,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, index) {
                          return Container(
                            width: MediaQuery.of(context).size.width * 0.90,
                            height: 50,
                            padding: EdgeInsets.only(
                                left: MediaQuery.of(context).size.width * 0.05,
                                right:
                                    MediaQuery.of(context).size.width * 0.05),
                            decoration: const BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: Color(0xffE3E3E3),
                                  width: 1.0,
                                ),
                              ),
                            ),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    snapshot.data![index],
                                    style: const TextStyle(
                                        fontSize: 13,
                                        fontFamily: 'SemiBold',
                                        color: Color(0xff202020)),
                                  ),
                                  const Icon(
                                    Icons.keyboard_arrow_right_rounded,
                                    color: Color(0xffFF4F4F),
                                    size: 25,
                                  ),
                                ]),
                          );
                        },
                      );
                    }
                  } else if (snapshot.hasError) {
                    return SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: 100,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Text("Something went wrong"),
                        ],
                      ),
                    );
                  }

                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 100,
                    child: const Center(
                        child: SizedBox(
                      width: 30,
                      height: 30,
                      child: CircularProgressIndicator(
                        color: Color(0xff00CE19),
                      ),
                    )),
                  );
                },
              ),
              const SizedBox(
                height: 20,
              ),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                Text(
                  "Show More",
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'SemiBold',
                      color: Color(0xffFF4F4F)),
                ),
              ]),
              const SizedBox(
                height: 50,
              ),
            ],
          ),
        ],
      ),
    )));
  }
}

class DiscountClip extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(10, size.height / 2);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}
