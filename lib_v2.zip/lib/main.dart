import 'package:flutter/material.dart';
import 'package:upscale/home.dart';
import 'package:upscale/splash.dart';

Future<void> main() async {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: 'Splash',
      routes: {
        'Splash': (context) => const Home(),
      },
    );
  }
}
