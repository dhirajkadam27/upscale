import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale/home.dart';

class PrivacyPolicy extends StatefulWidget {
  const PrivacyPolicy({super.key});

  @override
  State<PrivacyPolicy> createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<PrivacyPolicy> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: Colors.white,
      child: Stack(
        children: [
          Container(
            margin:
                EdgeInsets.only(left: MediaQuery.of(context).size.width * 0.05),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 30,
                ),
                const Text(
                  "Upscale",
                  style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'ExtraBold',
                      color: Color(0xffFF4F4F)),
                ),
                const SizedBox(
                  height: 50,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.90,
                  child: const Text(
                    "Privacy Policy",
                    style: TextStyle(
                        fontSize: 25,
                        fontFamily: 'ExtraBold',
                        color: Color(0xff202020)),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.90,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        "Click on the link to read all the privacy policy of our app",
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: 'Medium',
                            color: Color(0xff767676)),
                      ),
                      Text(
                        "privacy policy",
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: 'Medium',
                            color: Color(0xff469BFF)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 20,
            left: MediaQuery.of(context).size.width * 0.05,
            child: InkWell(
              onTap: () {
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => const Home()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width * 0.90,
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: const Color(0xffFF4F4F)),
                child: const Text(
                  "Agree and continue",
                  style: TextStyle(
                    fontSize: 15,
                    fontFamily: 'Bold',
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    )));
  }
}
