import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'get_started.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xffFF4F4F),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));

    Future.delayed(const Duration(seconds: 2), () async {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => const GetStarted()));
    });

    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: const Color(0xffFF4F4F),
      child: const Center(
          child: Text(
        "Upscale",
        style: TextStyle(
            fontSize: 60, fontFamily: 'ExtraBold', color: Colors.white),
      )),
    )));
  }
}
