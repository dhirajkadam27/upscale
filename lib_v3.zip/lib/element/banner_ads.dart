import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';
import 'package:shimmer/shimmer.dart';

class BannerAds extends StatefulWidget {
  const BannerAds({super.key});

  @override
  State<BannerAds> createState() => _BannerAdsState();
}

class _BannerAdsState extends State<BannerAds> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.90,
      margin: EdgeInsets.only(
          left: MediaQuery.of(context).size.width * 0.05,
          right: MediaQuery.of(context).size.width * 0.05,
          top: 10),
      child: SvgPicture.network(
        placeholderBuilder: (context) {
          return Shimmer.fromColors(
            baseColor: const Color(0xff2F2F2F),
            highlightColor: Colors.black,
            child: Container(
              width: MediaQuery.of(context).size.width * 0.90,
              height: 130,
              color: const Color(0xff2F2F2F),
            ),
          );
        },
        'https://mydukanpe.com/upscale/assets/Ads.svg',
      ),
    );
  }
}
