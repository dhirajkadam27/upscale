import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';

import '../screen/view.dart';

class MyCertificates extends StatefulWidget {
  const MyCertificates({super.key});

  @override
  State<MyCertificates> createState() => _MyCertificatesState();
}

class _MyCertificatesState extends State<MyCertificates> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  Future fetchRecommended() async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/upscale/api/recommended.php'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(
              left: MediaQuery.of(context).size.width * 0.05, top: 20),
          child: const Text(
            "Recent Viewed",
            style: TextStyle(
                fontFamily: 'Bold', fontSize: 15, color: Colors.white),
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          margin: const EdgeInsets.only(top: 10),
          child: Column(
            children: [
              const SizedBox(
                width: 10,
              ),
              FutureBuilder(
                future: fetchRecommended(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: snapshot.data!.length,
                      shrinkWrap: true,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => View(
                                      id: '1',
                                    )));
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            margin: EdgeInsets.only(
                                left: MediaQuery.of(context).size.width * 0.05,
                                top: 10),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10),
                                  child: Image.network(
                                    snapshot.data[index]['img'],
                                    width: 85,
                                    height: 60,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                const SizedBox(
                                  width: 15,
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width:
                                          (MediaQuery.of(context).size.width *
                                                  0.85) -
                                              85,
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        snapshot.data[index]['title'],
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontFamily: 'Bold',
                                            fontSize: 15),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      width:
                                          (MediaQuery.of(context).size.width *
                                                  0.85) -
                                              85,
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        snapshot.data[index]['tag'],
                                        style: const TextStyle(
                                            color: Color(0xffBFBFBF),
                                            fontFamily: 'Bold',
                                            fontSize: 15),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  }

                  // By default, show a loading spinner.
                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 175,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        Container(
                          width: 180,
                          height: 175,
                          margin: const EdgeInsets.only(right: 10),
                          color: const Color(0xff7D7B43),
                        ),
                        Container(
                          width: 180,
                          height: 175,
                          margin: const EdgeInsets.only(right: 10),
                          color: const Color(0xff60437D),
                        ),
                        Container(
                          width: 180,
                          height: 175,
                          margin: const EdgeInsets.only(right: 10),
                          color: const Color(0xff7D4343),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}
