import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';
import 'package:shimmer/shimmer.dart';

import '../screen/view.dart';

class Trending extends StatefulWidget {
  const Trending({super.key});

  @override
  State<Trending> createState() => _TrendingState();
}

class _TrendingState extends State<Trending> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  Future fetchRecommended() async {
    try {
      final fetch = await http.get(
          Uri.parse('https://mydukanpe.com/upscale/api/public/trending.php'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(
              left: MediaQuery.of(context).size.width * 0.05, top: 20),
          child: const Text(
            "Trending",
            style: TextStyle(
                fontFamily: 'Bold', fontSize: 15, color: Colors.white),
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          height: 180,
          margin: const EdgeInsets.only(top: 5),
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              const SizedBox(
                width: 10,
              ),
              FutureBuilder(
                future: fetchRecommended(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: snapshot.data!.length,
                      shrinkWrap: true,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => View(
                                      id: snapshot.data[index]['course_id'],
                                    )));
                          },
                          child: Container(
                            width: 180,
                            height: 175,
                            margin: const EdgeInsets.only(right: 10),
                            child: Column(children: [
                              Container(
                                padding:
                                    const EdgeInsets.only(top: 10, bottom: 10),
                                child: Image.network(
                                  snapshot.data[index]['img'],
                                  width: 165,
                                  height: 106,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                width: 165,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  snapshot.data[index]['title'],
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                              Container(
                                width: 165,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  snapshot.data[index]['tag'],
                                  style: const TextStyle(
                                      color: Color(0xffBFBFBF),
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ]),
                          ),
                        );
                      },
                    );
                  }

                  // By default, show a loading spinner.
                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 175,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        Container(
                          width: 180,
                          height: 175,
                          margin: const EdgeInsets.only(right: 10),
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xff2F2F2F),
                            highlightColor: Colors.black,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 130,
                              color: const Color(0xff2F2F2F),
                            ),
                          ),
                        ),
                        Container(
                          width: 180,
                          height: 175,
                          margin: const EdgeInsets.only(right: 10),
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xff2F2F2F),
                            highlightColor: Colors.black,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 130,
                              color: const Color(0xff2F2F2F),
                            ),
                          ),
                        ),
                        Container(
                          width: 180,
                          height: 175,
                          margin: const EdgeInsets.only(right: 10),
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xff2F2F2F),
                            highlightColor: Colors.black,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 130,
                              color: const Color(0xff2F2F2F),
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}
