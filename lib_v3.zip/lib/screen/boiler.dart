import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';

class Bolier extends StatefulWidget {
  const Bolier({super.key});

  @override
  State<Bolier> createState() => _BolierState();
}

class _BolierState extends State<Bolier> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: SafeArea(
          child: Stack(
        children: [],
      )),
    );
  }
}
