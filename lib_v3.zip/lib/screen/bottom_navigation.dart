import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:upscale02/screen/explore.dart';
import 'package:upscale02/screen/home.dart';
import 'package:upscale02/screen/my_certificate.dart';
import 'package:upscale02/screen/profile.dart';

class BottomNavigation extends StatefulWidget {
  const BottomNavigation({super.key});

  @override
  State<BottomNavigation> createState() => _BottomNavigationState();
}

class _BottomNavigationState extends State<BottomNavigation> {
  int index = 0;
  final screens = const [Home(), Explore(), MyCertificates(), Profile()];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Stack(
      children: [
        screens[index],
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black,
                  Color(0xff000536),
                ],
              ),
            ),
            padding: const EdgeInsets.only(top: 2, bottom: 2),
            child: BottomNavigationBar(
              elevation: 0, // to
              selectedItemColor: const Color(0xffFFFFFF),
              unselectedItemColor: const Color(0xffA0A0A0),
              unselectedLabelStyle: const TextStyle(fontFamily: 'Bold'),
              selectedLabelStyle: const TextStyle(fontFamily: 'Bold'),
              selectedFontSize: 12,
              backgroundColor: Colors.white.withOpacity(0.0),
              type: BottomNavigationBarType.fixed,
              currentIndex: index,
              onTap: (index) => setState(() {
                this.index = index;
              }),
              items: [
                BottomNavigationBarItem(
                    activeIcon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Home_fill.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Home.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    label: "Home"),
                BottomNavigationBarItem(
                    activeIcon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Search_fill.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Search.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    label: "Explore"),
                BottomNavigationBarItem(
                    activeIcon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Course_fill.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Course.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    label: "My Certificate"),
                BottomNavigationBarItem(
                    activeIcon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Profile_fill.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    icon: Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: SvgPicture.asset(
                        'assets/Profile.svg',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    label: "Profile"),
              ],
            ),
          ),
        ),
      ],
    )));
  }
}
