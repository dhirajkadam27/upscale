import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale02/screen/bottom_navigation.dart';

class Explore extends StatefulWidget {
  const Explore({super.key});

  @override
  State<Explore> createState() => _ExploreState();
}

class _ExploreState extends State<Explore> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: SafeArea(
          child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 80,
              alignment: Alignment.center,
              child: const Text(
                "Upscale",
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Black', fontSize: 35),
              ),
            ),
          ),
          Positioned(
            top: 80,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 100,
              child: ListView(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              const BottomNavigation()));
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 60,
                      margin: EdgeInsets.only(
                          top: 20,
                          bottom: 20,
                          left: MediaQuery.of(context).size.width * 0.05,
                          right: MediaQuery.of(context).size.width * 0.05),
                      color: const Color(0xff7D4377),
                      child: Center(
                        child: Row(
                          children: const [
                            SizedBox(
                              width: 20,
                            ),
                            Icon(
                              Icons.search,
                              size: 25,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "Search your query",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'SemiBold',
                                  fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        top: 20),
                    child: const Text(
                      "Programming",
                      style: TextStyle(
                          fontFamily: 'Bold',
                          fontSize: 15,
                          color: Colors.white),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff7D4343),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "HTML",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff437D50),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "CSS",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff7D7B43),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "Python",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff60437D),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "JAVA",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        top: 20),
                    child: const Text(
                      "Web Development",
                      style: TextStyle(
                          fontFamily: 'Bold',
                          fontSize: 15,
                          color: Colors.white),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff7D4343),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "HTML , CSS & JS",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff437D50),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "React Js",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff7D7B43),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "Angular",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.40,
                          height: 50,
                          color: const Color(0xff60437D),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Center(
                                child: Text(
                                  "PWA",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 140,
                  )
                ],
              ),
            ),
          )
        ],
      )),
    );
  }
}
