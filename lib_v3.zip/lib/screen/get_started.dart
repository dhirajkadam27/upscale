import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';
import 'package:upscale02/screen/name.dart';

class GetStarted extends StatefulWidget {
  const GetStarted({super.key});

  @override
  State<GetStarted> createState() => _GetStartedState();
}

class _GetStartedState extends State<GetStarted> {
  final user = Hive.box('User');

  @override
  void initState() {
    super.initState();
    logout();
  }

  Future logout() async {
    FirebaseAuth.instance.authStateChanges().listen((User? user) async {
      if (user == null) {
      } else {
        await GoogleSignIn().disconnect();
        FirebaseAuth.instance.signOut();
      }
    });
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: SafeArea(
          child: Stack(
        children: [
          Positioned(
            top: 0,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: 100,
              child: const Center(
                child: Text(
                  "Upscale",
                  style: TextStyle(
                      color: Colors.white, fontFamily: 'Black', fontSize: 35),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 30,
            left: MediaQuery.of(context).size.width * 0.05,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: SvgPicture.asset(
                    'assets/getStarted.svg',
                    width: 200,
                    height: 200,
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                const Text(
                  "Start your",
                  style: TextStyle(
                      color: Colors.white, fontFamily: 'Black', fontSize: 35),
                ),
                const Text(
                  "career Journey",
                  style: TextStyle(
                      color: Colors.white, fontFamily: 'Black', fontSize: 35),
                ),
                const Text(
                  "here.....",
                  style: TextStyle(
                      color: Colors.white, fontFamily: 'Black', fontSize: 35),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (BuildContext context) => const Name()));
                  },
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 60,
                    margin: const EdgeInsets.only(top: 20, bottom: 20),
                    color: const Color(0xff437D65),
                    child: const Center(
                      child: Text(
                        "Continue",
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Bold',
                            fontSize: 20),
                      ),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      )),
    );
  }
}
