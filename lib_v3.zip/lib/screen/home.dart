import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale02/element/recent_viewed.dart';
import 'package:upscale02/element/you_liked.dart';
import 'package:upscale02/element/recommended_for_today.dart';
import 'package:upscale02/element/trending.dart';
import 'package:upscale02/screen/bottom_navigation.dart';

import '../element/banner_ads.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: SafeArea(
          child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 80,
              alignment: Alignment.center,
              child: const Text(
                "Upscale",
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Black', fontSize: 35),
              ),
            ),
          ),
          Positioned(
            top: 80,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 100,
              child: ListView(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              const BottomNavigation()));
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 60,
                      margin: EdgeInsets.only(
                          top: 20,
                          bottom: 20,
                          left: MediaQuery.of(context).size.width * 0.05,
                          right: MediaQuery.of(context).size.width * 0.05),
                      color: const Color(0xff437D65),
                      child: Center(
                        child: Row(
                          children: const [
                            SizedBox(
                              width: 20,
                            ),
                            Icon(
                              Icons.search,
                              size: 25,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "Search your query",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'SemiBold',
                                  fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const BannerAds(),
                  const TodaysRecommendation(),
                  const Trending(),
                  const RecentViewed(),
                  const YouLiked(),
                  const SizedBox(
                    height: 140,
                  )
                ],
              ),
            ),
          )
        ],
      )),
    );
  }
}
