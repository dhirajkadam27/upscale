import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale02/screen/bottom_navigation.dart';

class MyCertificates extends StatefulWidget {
  const MyCertificates({super.key});

  @override
  State<MyCertificates> createState() => _MyCertificatesState();
}

class _MyCertificatesState extends State<MyCertificates> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: SafeArea(
          child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 80,
              alignment: Alignment.center,
              child: const Text(
                "Upscale",
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Black', fontSize: 35),
              ),
            ),
          ),
          Positioned(
            top: 80,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 100,
              child: ListView(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              const BottomNavigation()));
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 60,
                      margin: EdgeInsets.only(
                          top: 20,
                          bottom: 20,
                          left: MediaQuery.of(context).size.width * 0.05,
                          right: MediaQuery.of(context).size.width * 0.05),
                      color: const Color(0xff7D4377),
                      child: Center(
                        child: Row(
                          children: const [
                            SizedBox(
                              width: 20,
                            ),
                            Icon(
                              Icons.bookmark,
                              size: 25,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "Liked Courses",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'SemiBold',
                                  fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 250,
                    margin: const EdgeInsets.only(right: 10, top: 10),
                    child: Column(children: [
                      Container(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: Image.network(
                          "https://blog.hubspot.com/hubfs/bold-italicize-text-in-html.png",
                          width: MediaQuery.of(context).size.width * 0.90,
                          height: 180,
                          fit: BoxFit.cover,
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        alignment: Alignment.topLeft,
                        child: const Text(
                          "HTML Advance",
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Bold',
                              fontSize: 15),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        alignment: Alignment.topLeft,
                        child: const Text(
                          "Programming",
                          style: TextStyle(
                              color: Color(0xffBFBFBF),
                              fontFamily: 'Bold',
                              fontSize: 15),
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 250,
                    margin: const EdgeInsets.only(right: 10, top: 10),
                    child: Column(children: [
                      Container(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: Image.network(
                          "https://res.cloudinary.com/cloudinary-marketing/images/w_1540,h_847/f_auto,q_auto/v1649718594/Web_Assets/blog/working_with_css_22218720ab/working_with_css_22218720ab-jpg?_i=AA",
                          width: MediaQuery.of(context).size.width * 0.90,
                          height: 180,
                          fit: BoxFit.cover,
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        alignment: Alignment.topLeft,
                        child: const Text(
                          "CSS Advance",
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Bold',
                              fontSize: 15),
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        alignment: Alignment.topLeft,
                        child: const Text(
                          "Programming",
                          style: TextStyle(
                              color: Color(0xffBFBFBF),
                              fontFamily: 'Bold',
                              fontSize: 15),
                        ),
                      ),
                    ]),
                  ),
                  const SizedBox(
                    height: 140,
                  )
                ],
              ),
            ),
          )
        ],
      )),
    );
  }
}
