import 'dart:convert';
import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';
import 'package:upscale02/screen/bottom_navigation.dart';
import 'package:http/http.dart' as http;

class Name extends StatefulWidget {
  const Name({super.key});

  @override
  State<Name> createState() => _NameState();
}

class _NameState extends State<Name> {
  TextEditingController nameController = TextEditingController();
  bool loader = true;
  bool error = false;
  String errorTxt = "Something went wrong";
  String email = "";
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
    googleLogin();
  }

  Future signIn() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/upscale/api/public/signIn.php?name=${nameController.text}&email=$email'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          setState(() {
            loader = false;
          });
          user.put("user", "Y");
          user.put("user_id", reponse['id']);
          user.put("user_name", nameController.text);
          user.put("user_email", email);

          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => const BottomNavigation()));
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        setState(() {
          error = true;
          errorTxt = "Something went wrong";
          loader = false;
        });
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        error = true;
        errorTxt = "Internet is not connected";
        loader = false;
      });
    }
  }

  googleLogin() async {
    GoogleSignIn _googleSignIn = GoogleSignIn();
    try {
      var reslut = await _googleSignIn.signIn();
      if (reslut == null) {
        return;
      }

      final userData = await reslut.authentication;
      final credential = GoogleAuthProvider.credential(
          accessToken: userData.accessToken, idToken: userData.idToken);
      var finalResult =
          await FirebaseAuth.instance.signInWithCredential(credential);
      setState(() {
        loader = false;
        email = reslut.email;
        nameController.text = reslut.displayName!;
      });
      if (reslut.displayName == null) {
        setState(() {
          error = true;
          errorTxt = "Something went wrong";
          loader = false;
        });
      }
    } catch (errors) {
      setState(() {
        error = true;
        errorTxt = "Something went wrong";
        loader = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: SafeArea(
          child: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: [
            Positioned(
              top: 0,
              left: MediaQuery.of(context).size.width * 0.05,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 100,
                    alignment: Alignment.center,
                    child: const Text(
                      "Upscale",
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Black',
                          fontSize: 35),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "What’s your name?",
                    style: TextStyle(
                        color: Colors.white, fontFamily: 'Bold', fontSize: 20),
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 50,
                      color: const Color(0xff8E8DD9),
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      margin: const EdgeInsets.only(top: 10),
                      child: TextField(
                        controller: nameController,
                        style: const TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                            fontFamily: 'SemiBold'),
                        decoration: const InputDecoration(
                            hintStyle: TextStyle(
                                fontSize: 15,
                                color: Colors.white,
                                fontFamily: 'SemiBold'),
                            border: InputBorder.none,
                            hintText: 'Enter Your Name',
                            fillColor: Colors.white),
                      )),
                ],
              ),
            ),
            Positioned(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: () {
                      setState(() {
                        loader = true;
                      });
                      signIn();
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 60,
                      color: const Color(0xff437D65),
                      child: const Center(
                        child: Text(
                          "Continue",
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Bold',
                              fontSize: 20),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            loader
                ? Positioned(
                    top: 0,
                    left: 0,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height,
                      color: Colors.black.withOpacity(0.5),
                      child: const Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ))
                : const Text(""),
            error
                ? Positioned(
                    bottom: 0,
                    left: 0,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height,
                      color: Colors.black.withOpacity(0.5),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              padding: EdgeInsets.all(
                                  MediaQuery.of(context).size.width * 0.05),
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color(0xff2F1E61),
                                    Colors.black,
                                  ],
                                ),
                              ),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      "Opps",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: 'Black',
                                          fontSize: 25),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      errorTxt,
                                      style: const TextStyle(
                                          color: Color(0xffBFBFBF),
                                          fontFamily: 'Bold',
                                          fontSize: 20),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        const Name()));
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.90,
                                        height: 60,
                                        color: const Color(0xff437D65),
                                        child: const Center(
                                          child: Text(
                                            "Okay",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontFamily: 'Bold',
                                                fontSize: 20),
                                          ),
                                        ),
                                      ),
                                    )
                                  ]),
                            )
                          ]),
                    ))
                : const Text(""),
          ],
        ),
      )),
    );
  }
}
