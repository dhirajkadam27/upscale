import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';
import 'package:shimmer/shimmer.dart';
import 'package:upscale02/screen/mcq.dart';
import 'package:upscale02/screen/plan.dart';
import 'package:http/http.dart' as http;

class Plan extends StatefulWidget {
  String id;
  Plan({super.key, required this.id});

  @override
  State<Plan> createState() => _PlanState();
}

class _PlanState extends State<Plan> {
  final user = Hive.box('User');
  String img = "";
  String title = "";
  String tag = "";
  String level = "";
  String time = "";
  String creatorname = "";
  String creatortag = "";
  String creatorverify = "";
  String shortdesc = "";
  String bigdesc = "";
  @override
  void initState() {
    super.initState();
    fetchCourse();
  }

  Future fetchCourse() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/upscale/api/public/view.php?id=${widget.id}'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        fetchCreator(response[0]['creator_id']);
        setState(() {
          img = response[0]['img'];
          title = response[0]['title'];
          tag = response[0]['tag'];
          level = response[0]['level'];
          time = response[0]['time'];
          shortdesc = response[0]['short_desc'];
          bigdesc = response[0]['big_desc'];
        });
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  Future fetchCreator(id) async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/upscale/api/public/creator.php?id=$id'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        setState(() {
          creatorname = response[0]['name'];
          creatortag = response[0]['tag'];
          creatorverify = response[0]['verified'];
        });
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.black.withOpacity(0),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: Stack(
        children: [
          img == "" ? const Text("") : Image.network(img, fit: BoxFit.cover),
          ClipRRect(
            // Clip it cleanly.
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 100, sigmaY: 100),
              child: Container(
                color: const Color(0xff00020C).withOpacity(0.3),
                alignment: Alignment.center,
                child: ListView(children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.20,
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    alignment: Alignment.center,
                    child: img == ""
                        ? Shimmer.fromColors(
                            baseColor: const Color(0xff2F2F2F),
                            highlightColor: Colors.black,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.70,
                              height: 160,
                              color: const Color(0xff2F2F2F),
                            ),
                          )
                        : Image.network(
                            img,
                            width: MediaQuery.of(context).size.width * 0.70,
                            height: 160,
                            fit: BoxFit.cover,
                          ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        title == ""
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Shimmer.fromColors(
                                    baseColor: const Color(0xff2F2F2F),
                                    highlightColor: Colors.black,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.90,
                                      height: 10,
                                      color: const Color(0xff2F2F2F),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Shimmer.fromColors(
                                    baseColor: const Color(0xff2F2F2F),
                                    highlightColor: Colors.black,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.80,
                                      height: 10,
                                      color: const Color(0xff2F2F2F),
                                    ),
                                  )
                                ],
                              )
                            : Container(
                                width: 165,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  title,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                        tag == ""
                            ? Shimmer.fromColors(
                                baseColor: const Color(0xff2F2F2F),
                                highlightColor: Colors.black,
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  height: 10,
                                  margin: const EdgeInsets.only(top: 10),
                                  color: const Color(0xff2F2F2F),
                                ),
                              )
                            : Container(
                                width: 165,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  tag,
                                  style: const TextStyle(
                                      color: Color(0xffBFBFBF),
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                      ],
                    ),
                  ),
                  Container(
                    width: 165,
                    alignment: Alignment.topLeft,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: const Text(
                      "Course Price",
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Bold',
                          fontSize: 15),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(
                        top: 10,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(right: 20),
                          child: Text(
                            "₹499",
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Bold',
                                fontSize: 25),
                          ),
                        ),
                        Stack(
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(left: 7),
                              child: Text(
                                "₹1999",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Medium',
                                    fontSize: 20),
                              ),
                            ),
                            Container(
                              width: 65,
                              height: 2,
                              color: Colors.red,
                              margin: const EdgeInsets.only(top: 10),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 165,
                    alignment: Alignment.topLeft,
                    margin: EdgeInsets.only(
                        top: 10,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: const Text(
                      "You have saved ₹899 on this course",
                      style: TextStyle(
                          color: Color(0xff437D65),
                          fontFamily: 'Bold',
                          fontSize: 15),
                    ),
                  ),
                  const SizedBox(
                    height: 100,
                  )
                ]),
              ),
            ),
          ),
          Positioned(
              bottom: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.only(bottom: 20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black,
                      Color(0xff000536),
                    ],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const Mcq()));
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.45,
                        height: 40,
                        decoration: BoxDecoration(
                            color: Colors.black,
                            border: Border.all(
                                width: 2, color: const Color(0xff437D65))),
                        child: const Center(
                          child: Text(
                            "Preview",
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'SemiBold',
                                fontSize: 15),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const Mcq()));
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.45,
                        height: 40,
                        color: const Color(0xff437D65),
                        child: const Center(
                          child: Text(
                            "Buy Now",
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'SemiBold',
                                fontSize: 15),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ))
        ],
      ),
    );
  }
}
