import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:upscale02/screen/splash.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final user = Hive.box('User');
  String name = "";
  String email = "";
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('user_name') != null) {
      setState(() {
        name = user.get('user_name');
      });
    }
    if (user.get('user_email') != null) {
      setState(() {
        email = user.get('user_email');
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00020C),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: SafeArea(
          child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 80,
              alignment: Alignment.center,
              child: const Text(
                "Upscale",
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Black', fontSize: 35),
              ),
            ),
          ),
          Positioned(
            top: 80,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 100,
              child: ListView(
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        top: 20),
                    child: const Text(
                      "Profile",
                      style: TextStyle(
                          fontFamily: 'Bold',
                          fontSize: 15,
                          color: Colors.white),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        top: 20,
                        bottom: 20),
                    child: Row(
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: const Color(0xff44437D)),
                          child: Center(
                            child: Text(
                              name[0],
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Bold',
                                  fontSize: 40),
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              name,
                              style: const TextStyle(
                                  fontFamily: 'Bold',
                                  fontSize: 20,
                                  color: Colors.white),
                            ),
                            const SizedBox(
                              height: 7,
                            ),
                            Text(
                              email,
                              style: const TextStyle(
                                  fontFamily: 'SemiBold',
                                  fontSize: 10,
                                  color: Color(0xffBFBFBF)),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05,
                        top: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Edit Profile",
                              style: TextStyle(
                                  fontFamily: 'Bold',
                                  fontSize: 20,
                                  color: Colors.white),
                            ),
                            SizedBox(
                              height: 7,
                            ),
                            Text(
                              "Change your personal details.",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  fontSize: 10,
                                  color: Color(0xffBFBFBF)),
                            ),
                          ],
                        ),
                        const Icon(
                          Icons.keyboard_arrow_right_outlined,
                          color: Colors.white,
                          size: 30,
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05,
                        top: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Privacy Poilcy",
                              style: TextStyle(
                                  fontFamily: 'Bold',
                                  fontSize: 20,
                                  color: Colors.white),
                            ),
                            SizedBox(
                              height: 7,
                            ),
                            Text(
                              "Important for both of us.",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  fontSize: 10,
                                  color: Color(0xffBFBFBF)),
                            ),
                          ],
                        ),
                        const Icon(
                          Icons.keyboard_arrow_right_outlined,
                          color: Colors.white,
                          size: 30,
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05,
                        top: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Version",
                              style: TextStyle(
                                  fontFamily: 'Bold',
                                  fontSize: 20,
                                  color: Colors.white),
                            ),
                            SizedBox(
                              height: 7,
                            ),
                            Text(
                              "Version 0.01",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  fontSize: 10,
                                  color: Color(0xffBFBFBF)),
                            ),
                          ],
                        ),
                        const Icon(
                          Icons.keyboard_arrow_right_outlined,
                          color: Colors.white,
                          size: 30,
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05,
                        top: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Terms and Conditions",
                              style: TextStyle(
                                  fontFamily: 'Bold',
                                  fontSize: 20,
                                  color: Colors.white),
                            ),
                            SizedBox(
                              height: 7,
                            ),
                            Text(
                              "All the stuff you need to know.",
                              style: TextStyle(
                                  fontFamily: 'SemiBold',
                                  fontSize: 10,
                                  color: Color(0xffBFBFBF)),
                            ),
                          ],
                        ),
                        const Icon(
                          Icons.keyboard_arrow_right_outlined,
                          color: Colors.white,
                          size: 30,
                        )
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      user.delete("user");
                      user.delete("user_id");
                      user.delete("user_name");

                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => const Splash()));
                    },
                    child: Padding(
                      padding: EdgeInsets.only(
                          left: MediaQuery.of(context).size.width * 0.05,
                          right: MediaQuery.of(context).size.width * 0.05,
                          top: 30),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                "Logout",
                                style: TextStyle(
                                    fontFamily: 'Bold',
                                    fontSize: 20,
                                    color: Colors.white),
                              ),
                              SizedBox(
                                height: 7,
                              ),
                              Text(
                                "You are logged in as Dhiraj Kadam",
                                style: TextStyle(
                                    fontFamily: 'SemiBold',
                                    fontSize: 10,
                                    color: Color(0xffBFBFBF)),
                              ),
                            ],
                          ),
                          const Icon(
                            Icons.keyboard_arrow_right_outlined,
                            color: Colors.white,
                            size: 30,
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 140,
                  )
                ],
              ),
            ),
          )
        ],
      )),
    );
  }
}
