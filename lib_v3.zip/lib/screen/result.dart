import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;

class Result extends StatefulWidget {
  const Result({super.key});

  @override
  State<Result> createState() => _ResultState();
}

class _ResultState extends State<Result> {
  final user = Hive.box('User');
  int initialPoint = 0;
  int length = 0;
  String img = "";

  late Future _userActivityLog;

  @override
  void initState() {
    super.initState();
    fetchCourse();
    _userActivityLog = fetchMCQS();
  }

  Future fetchCourse() async {
    try {
      final fetch = await http.get(
          Uri.parse('https://mydukanpe.com/upscale/api/public/view.php?id=1'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        setState(() {
          img = response[0]['img'];
        });
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  Future fetchMCQS() async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/upscale/api/public/mcq.php'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        length = response.length;
        print(response.length);
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.black.withOpacity(0),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: Stack(
        children: [
          Image.network(img, fit: BoxFit.cover),
          ClipRRect(
            // Clip it cleanly.
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 100, sigmaY: 100),
              child: Container(
                color: const Color(0xff00020C).withOpacity(0.3),
                alignment: Alignment.center,
                child: ListView(children: [
                  Column(
                    children: [
                      const SizedBox(
                        height: 100,
                      ),
                      const Text(
                        "😁",
                        style: TextStyle(
                          fontSize: 100,
                          color: Colors.white,
                          fontFamily: 'SemiBold',
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                        "28/30",
                        style: TextStyle(
                          fontSize: 20,
                          color: Color(0xffD5D5D5),
                          fontFamily: 'ExtraBold',
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      const Text(
                        "Excellent",
                        style: TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          fontFamily: 'ExtraBold',
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      const Text(
                        "Well done!! Keep it up",
                        style: TextStyle(
                          fontSize: 15,
                          color: Color(0xffD5D5D5),
                          fontFamily: 'ExtraBold',
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        margin: EdgeInsets.only(
                            top: 20,
                            left: MediaQuery.of(context).size.width * 0.05,
                            right: MediaQuery.of(context).size.width * 0.05),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 1, color: const Color(0xffBFBFBF)),
                            color: Colors.white.withOpacity(0.19)),
                        child: SvgPicture.asset(
                          'assets/Cert.svg',
                          width: MediaQuery.of(context).size.width * 0.80,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            width: 80,
                            height: 35,
                            color: const Color(0xff437D65),
                            margin: const EdgeInsets.all(10),
                            child: const Center(
                              child: Text(
                                "Share",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'SemiBold',
                                    fontSize: 15),
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  )
                ]),
              ),
            ),
          ),
          Positioned(
              bottom: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.only(bottom: 10),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black,
                      Color(0xff000536),
                    ],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 40,
                      color: const Color(0xff437D65),
                      margin: const EdgeInsets.all(10),
                      child: const Center(
                        child: Text(
                          "Download Certificate",
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'SemiBold',
                              fontSize: 15),
                        ),
                      ),
                    ),
                  ],
                ),
              ))
        ],
      ),
    );
  }
}
