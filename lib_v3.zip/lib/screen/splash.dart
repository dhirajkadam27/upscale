import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:upscale02/screen/bottom_navigation.dart';
import 'package:upscale02/screen/get_started.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  double left = 300;
  double top = 100;
  double opacity = 0;
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
    _timer();
  }

  void _timer() {
    Future.delayed(const Duration(milliseconds: 100)).then((_) {
      setState(() {
        left = MediaQuery.of(context).size.width * 0.10;
        top = MediaQuery.of(context).size.height * 0.85;
        opacity = 1;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 2), () async {
      if (user.get('user') == null) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => const GetStarted()));
      } else {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => const BottomNavigation()));
      }
    });

    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: Stack(
        children: [
          SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 700),
            top: 0,
            left: left,
            child: Container(
              width: 3,
              height: MediaQuery.of(context).size.height,
              color: Colors.white,
            ),
          ),
          AnimatedPositioned(
            top: top,
            left: 0,
            duration: const Duration(milliseconds: 700),
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 3,
              color: Colors.white,
            ),
          ),
          AnimatedOpacity(
            duration: const Duration(milliseconds: 1200),
            opacity: opacity,
            child: const Center(
              child: Text(
                "Upscale",
                style: TextStyle(
                    color: Colors.white, fontFamily: 'Black', fontSize: 50),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
