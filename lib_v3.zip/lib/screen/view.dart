import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';
import 'package:shimmer/shimmer.dart';
import 'package:upscale02/screen/plan.dart';
import 'package:http/http.dart' as http;

class View extends StatefulWidget {
  String id;
  View({super.key, required this.id});

  @override
  State<View> createState() => _ViewState();
}

class _ViewState extends State<View> {
  final user = Hive.box('User');
  String img = "";
  String title = "";
  String tag = "";
  String level = "";
  String time = "";
  String creatorname = "";
  String creatortag = "";
  String creatorverify = "";
  String shortdesc = "";
  String bigdesc = "";
  @override
  void initState() {
    super.initState();
    fetchCourse();
  }

  Future fetchCourse() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/upscale/api/public/view.php?id=${widget.id}'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        fetchCreator(response[0]['creator_id']);
        setState(() {
          img = response[0]['img'];
          title = response[0]['title'];
          tag = response[0]['tag'];
          level = response[0]['level'];
          time = response[0]['time'];
          shortdesc = response[0]['short_desc'];
          bigdesc = response[0]['big_desc'];
        });
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  Future fetchCreator(id) async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/upscale/api/public/creator.php?id=$id'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        setState(() {
          creatorname = response[0]['name'];
          creatortag = response[0]['tag'];
          creatorverify = response[0]['verified'];
        });
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.black.withOpacity(0),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff00020C),
      body: Stack(
        children: [
          img == "" ? const Text("") : Image.network(img, fit: BoxFit.cover),
          ClipRRect(
            // Clip it cleanly.
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 100, sigmaY: 100),
              child: Container(
                color: const Color(0xff00020C).withOpacity(0.3),
                alignment: Alignment.center,
                child: ListView(children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.20,
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    alignment: Alignment.center,
                    child: img == ""
                        ? Shimmer.fromColors(
                            baseColor: const Color(0xff2F2F2F),
                            highlightColor: Colors.black,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.70,
                              height: 160,
                              color: const Color(0xff2F2F2F),
                            ),
                          )
                        : Image.network(
                            img,
                            width: MediaQuery.of(context).size.width * 0.70,
                            height: 160,
                            fit: BoxFit.cover,
                          ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        title == ""
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Shimmer.fromColors(
                                    baseColor: const Color(0xff2F2F2F),
                                    highlightColor: Colors.black,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.90,
                                      height: 10,
                                      color: const Color(0xff2F2F2F),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Shimmer.fromColors(
                                    baseColor: const Color(0xff2F2F2F),
                                    highlightColor: Colors.black,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.80,
                                      height: 10,
                                      color: const Color(0xff2F2F2F),
                                    ),
                                  )
                                ],
                              )
                            : Container(
                                width: 165,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  title,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                        tag == ""
                            ? Shimmer.fromColors(
                                baseColor: const Color(0xff2F2F2F),
                                highlightColor: Colors.black,
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  height: 10,
                                  margin: const EdgeInsets.only(top: 10),
                                  color: const Color(0xff2F2F2F),
                                ),
                              )
                            : Container(
                                width: 165,
                                alignment: Alignment.topLeft,
                                child: Text(
                                  tag,
                                  style: const TextStyle(
                                      color: Color(0xffBFBFBF),
                                      fontFamily: 'Bold',
                                      fontSize: 15),
                                ),
                              ),
                      ],
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: Text(
                      shortdesc,
                      style: const TextStyle(
                          color: Color(0xffBFBFBF),
                          fontFamily: 'SemiBold',
                          fontSize: 15),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 1, color: const Color(0xffBFBFBF)),
                        color: Colors.white.withOpacity(0.19)),
                    child: Column(children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            Icons.timeline,
                            color: Colors.white,
                            size: 20,
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Course Level",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Bold',
                                    fontSize: 15),
                              ),
                              level != ""
                                  ? Text(
                                      level,
                                      style: const TextStyle(
                                          color: Color(0xffBFBFBF),
                                          fontFamily: 'Medium',
                                          fontSize: 15),
                                    )
                                  : Shimmer.fromColors(
                                      baseColor: Colors.white,
                                      highlightColor: Colors.grey,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.40,
                                        height: 10,
                                        margin: const EdgeInsets.only(top: 2),
                                        color: const Color(0xff2F2F2F),
                                      ),
                                    ),
                              const SizedBox(
                                height: 10,
                              )
                            ],
                          )
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            Icons.access_time,
                            color: Colors.white,
                            size: 20,
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Time to complete",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Bold',
                                    fontSize: 15),
                              ),
                              time != ""
                                  ? Text(
                                      "Approx. $time",
                                      style: const TextStyle(
                                          color: Color(0xffBFBFBF),
                                          fontFamily: 'Medium',
                                          fontSize: 15),
                                    )
                                  : Shimmer.fromColors(
                                      baseColor: Colors.white,
                                      highlightColor: Colors.grey,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.40,
                                        height: 10,
                                        margin: const EdgeInsets.only(top: 2),
                                        color: const Color(0xff2F2F2F),
                                      ),
                                    ),
                              const SizedBox(
                                height: 10,
                              )
                            ],
                          )
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            Icons.stars,
                            color: Colors.white,
                            size: 20,
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                "Certificate of completion",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Bold',
                                    fontSize: 15),
                              ),
                              Text(
                                "Included with paid plans",
                                style: TextStyle(
                                    color: Color(0xffBFBFBF),
                                    fontFamily: 'Medium',
                                    fontSize: 15),
                              ),
                              SizedBox(
                                height: 10,
                              )
                            ],
                          )
                        ],
                      ),
                    ]),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: const Text(
                      "Course Creator",
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Bold',
                          fontSize: 15),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 1, color: const Color(0xffBFBFBF)),
                        color: Colors.white.withOpacity(0.19)),
                    child: Column(children: [
                      Row(
                        children: [
                          creatorname == ""
                              ? Shimmer.fromColors(
                                  baseColor: Colors.white,
                                  highlightColor: Colors.grey,
                                  child: Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        color: const Color(0xff2F2F2F)),
                                  ),
                                )
                              : Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(100),
                                      color: const Color(0xff437D65)),
                                  child: Center(
                                    child: Text(
                                      creatorname[0],
                                      style: const TextStyle(
                                          color: Colors.white,
                                          fontFamily: 'Bold',
                                          fontSize: 25),
                                    ),
                                  ),
                                ),
                          const SizedBox(
                            width: 10,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  creatorname == ""
                                      ? Shimmer.fromColors(
                                          baseColor: Colors.white,
                                          highlightColor: Colors.grey,
                                          child: Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.40,
                                            height: 10,
                                            color: const Color(0xff2F2F2F),
                                          ),
                                        )
                                      : Text(
                                          creatorname,
                                          style: const TextStyle(
                                              fontFamily: 'Bold',
                                              fontSize: 15,
                                              color: Colors.white),
                                        ),
                                  const SizedBox(
                                    width: 5,
                                  ),
                                  creatorverify != ""
                                      ? const Icon(
                                          Icons.verified,
                                          size: 15,
                                          color: Colors.white,
                                        )
                                      : Shimmer.fromColors(
                                          baseColor: Colors.white,
                                          highlightColor: Colors.grey,
                                          child: Container(
                                            width: 15,
                                            height: 15,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(100),
                                                color: const Color(0xff2F2F2F)),
                                          ),
                                        ),
                                ],
                              ),
                              const SizedBox(
                                height: 3,
                              ),
                              creatortag == ""
                                  ? Shimmer.fromColors(
                                      baseColor: Colors.white,
                                      highlightColor: Colors.grey,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.40,
                                        height: 10,
                                        margin: const EdgeInsets.only(top: 5),
                                        color: const Color(0xff2F2F2F),
                                      ),
                                    )
                                  : Text(
                                      creatortag,
                                      style: const TextStyle(
                                          fontFamily: 'SemiBold',
                                          fontSize: 10,
                                          color: Color(0xffBFBFBF)),
                                    ),
                            ],
                          )
                        ],
                      ),
                    ]),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: const Text(
                      "About Course",
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Bold',
                          fontSize: 15),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: bigdesc == ""
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Shimmer.fromColors(
                                baseColor: const Color(0xff2F2F2F),
                                highlightColor: Colors.black,
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.90,
                                  height: 10,
                                  color: const Color(0xff2F2F2F),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Shimmer.fromColors(
                                baseColor: const Color(0xff2F2F2F),
                                highlightColor: Colors.black,
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.80,
                                  height: 10,
                                  color: const Color(0xff2F2F2F),
                                ),
                              )
                            ],
                          )
                        : Text(
                            bigdesc,
                            style: const TextStyle(
                                color: Color(0xffBFBFBF),
                                fontFamily: 'SemiBold',
                                fontSize: 15),
                          ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: const Text(
                      "Preview Certificate",
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Bold',
                          fontSize: 15),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    margin: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 1, color: const Color(0xffBFBFBF)),
                        color: Colors.white.withOpacity(0.19)),
                    child: SvgPicture.asset(
                      'assets/Cert.svg',
                      width: MediaQuery.of(context).size.width * 0.80,
                    ),
                  ),
                  const SizedBox(
                    height: 100,
                  )
                ]),
              ),
            ),
          ),
          Positioned(
              bottom: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.only(bottom: 10),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black,
                      Color(0xff000536),
                    ],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => Plan(id: widget.id)));
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        height: 40,
                        color: const Color(0xff437D65),
                        margin: const EdgeInsets.all(10),
                        child: const Center(
                          child: Text(
                            "Enroll Now",
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'SemiBold',
                                fontSize: 15),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ))
        ],
      ),
    );
  }
}
