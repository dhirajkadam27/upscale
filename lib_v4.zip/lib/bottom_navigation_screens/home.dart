import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:upscale2/elements/mini_certificate.dart';
import '/elements/mini_course.dart';
import '/elements/title_bar.dart';
import 'package:http/http.dart' as http;

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  void initState() {
    super.initState();
    popularCertificate();
    categories();
    offers();
  }

  Future popularCertificate() async {
    try {
      final response = await http.get(
          Uri.parse('https://mydukanpe.com/upscale/popular_certificates.php'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List planData = jsonDecode(response.body);
        // print(planData[0]['img']);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        // showerror(context, "Something went wrong");
        // throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      // showerror(context, "Internet is not Connected");

      throw Exception('Something Went Wrong');
    }
  }

  Future categories() async {
    try {
      final response = await http
          .get(Uri.parse('https://mydukanpe.com/upscale/categories.php'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List planData = jsonDecode(response.body);
        // print(planData[0]['img']);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        // showerror(context, "Something went wrong");
        // throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      // showerror(context, "Internet is not Connected");

      throw Exception('Something Went Wrong');
    }
  }

  Future offers() async {
    try {
      final response =
          await http.get(Uri.parse('https://mydukanpe.com/upscale/offers.php'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List planData = jsonDecode(response.body);
        // print(planData[0]['img']);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        // showerror(context, "Something went wrong");
        // throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      // showerror(context, "Internet is not Connected");

      throw Exception('Something Went Wrong');
    }
  }

  Future certificate() async {
    try {
      final response = await http
          .get(Uri.parse('https://mydukanpe.com/upscale/certificate.php'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List planData = jsonDecode(response.body);
        // print(planData[0]['img']);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        // showerror(context, "Something went wrong");
        // throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      // showerror(context, "Internet is not Connected");

      throw Exception('Something Went Wrong');
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    return Scaffold(
        body: SafeArea(
            child: Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: Colors.white,
      child: Stack(
        children: [
          ListView(
            children: [
              const TitleBar(),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 80,
                alignment: Alignment.center,
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.90,
                  height: 50,
                  decoration: BoxDecoration(
                      border: Border.all(
                          width: 2,
                          color: const Color(0xffE6E6E6),
                          style: BorderStyle.solid),
                      borderRadius: BorderRadius.circular(5)),
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: const [
                      Icon(
                        Icons.search_outlined,
                        size: 25,
                        color: Color(0xff767676),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Explore courses and features",
                        style: TextStyle(
                            fontSize: 15,
                            fontFamily: 'Medium',
                            color: Color(0xff767676)),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 180,
                alignment: Alignment.center,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(
                    'https://s3.ap-south-1.amazonaws.com/guvi-2.0/banner/x_mas_banner_2_(V1).webp',
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 160,
                    fit: BoxFit.fill,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05, top: 20),
                child: const Text(
                  "Popular courses",
                  style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 250,
                margin: const EdgeInsets.only(top: 20, bottom: 20),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    FutureBuilder(
                      future: popularCertificate(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            itemCount: snapshot.data!.length,
                            shrinkWrap: true,
                            itemBuilder: (BuildContext context, index) {
                              return MiniCourse(
                                img: snapshot.data![index]['img'],
                                enroll: snapshot.data![index]['enroll'],
                                title: snapshot.data![index]['title'],
                                tag: snapshot.data![index]['tag'],
                                mrp: snapshot.data![index]['mrp'],
                                discount: snapshot.data![index]['discount'],
                              );
                            },
                          );
                        } else if (snapshot.hasError) {
                          return Container(
                            width: MediaQuery.of(context).size.width,
                            height: 100,
                            alignment: Alignment.center,
                            child: const Text(
                              "Something went wrong",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontFamily: 'Medium',
                                  color: Color(0xff202020)),
                            ),
                          );
                        }
                        // By default, show a loading spinner.
                        return SizedBox(
                          width: MediaQuery.of(context).size.width,
                          height: 100,
                          child: const Center(
                              child: SizedBox(
                            width: 30,
                            height: 30,
                            child: CircularProgressIndicator(
                              color: Color(0xffFF4F4F),
                            ),
                          )),
                        );
                      },
                    ),
                    const SizedBox(
                      width: 20,
                    )
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Categories",
                  style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              Container(
                  width: MediaQuery.of(context).size.width,
                  height: 40,
                  margin: const EdgeInsets.only(top: 20, bottom: 20),
                  alignment: Alignment.center,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      FutureBuilder(
                        future: categories(),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            return ListView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              scrollDirection: Axis.horizontal,
                              itemCount: snapshot.data!.length,
                              shrinkWrap: true,
                              itemBuilder: (BuildContext context, index) {
                                return Container(
                                    margin: const EdgeInsets.only(left: 20),
                                    height: 45,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            width: 2,
                                            color: const Color(0xffE6E6E6),
                                            style: BorderStyle.solid),
                                        borderRadius: BorderRadius.circular(5)),
                                    padding: const EdgeInsets.all(10),
                                    child: Text(
                                      snapshot.data![index],
                                      style: const TextStyle(
                                          fontSize: 13,
                                          fontFamily: 'Bold',
                                          color: Color(0xff767676)),
                                    ));
                              },
                            );
                          } else if (snapshot.hasError) {
                            return Container(
                              width: MediaQuery.of(context).size.width,
                              height: 100,
                              alignment: Alignment.center,
                              child: const Text(
                                "Something went wrong",
                                style: TextStyle(
                                    fontSize: 15,
                                    fontFamily: 'Medium',
                                    color: Color(0xff202020)),
                              ),
                            );
                          }
                          // By default, show a loading spinner.
                          return SizedBox(
                            width: MediaQuery.of(context).size.width,
                            height: 100,
                            child: const Center(
                                child: SizedBox(
                              width: 30,
                              height: 30,
                              child: CircularProgressIndicator(
                                color: Color(0xffFF4F4F),
                              ),
                            )),
                          );
                        },
                      ),
                      Container(
                          margin: const EdgeInsets.only(left: 20),
                          height: 45,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  width: 2,
                                  color: const Color(0xffE6E6E6),
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(5)),
                          padding: const EdgeInsets.all(10),
                          child: const Text(
                            "Android Development",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'Bold',
                                color: Color(0xff767676)),
                          )),
                      Container(
                          margin: const EdgeInsets.only(left: 20),
                          height: 45,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  width: 2,
                                  color: const Color(0xffE6E6E6),
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(5)),
                          padding: const EdgeInsets.all(10),
                          child: const Text(
                            "IOS Development",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'Bold',
                                color: Color(0xff767676)),
                          )),
                      Container(
                          margin: const EdgeInsets.only(left: 20),
                          height: 45,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  width: 2,
                                  color: const Color(0xffE6E6E6),
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(5)),
                          padding: const EdgeInsets.all(10),
                          child: const Text(
                            "Programming",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'Bold',
                                color: Color(0xff767676)),
                          )),
                      const SizedBox(
                        width: 20,
                      ),
                    ],
                  )),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Recent Achievers",
                  style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 250,
                margin: const EdgeInsets.only(top: 20, bottom: 20),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    FutureBuilder(
                      future: certificate(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            itemCount: snapshot.data!.length,
                            shrinkWrap: true,
                            itemBuilder: (BuildContext context, index) {
                              return MiniCertificate(
                                  name: snapshot.data![index]['name'],
                                  tag: snapshot.data![index]['tag']);
                            },
                          );
                        } else if (snapshot.hasError) {
                          return Container(
                            width: MediaQuery.of(context).size.width,
                            height: 100,
                            alignment: Alignment.center,
                            child: const Text(
                              "Something went wrong",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontFamily: 'Medium',
                                  color: Color(0xff202020)),
                            ),
                          );
                        }
                        // By default, show a loading spinner.
                        return SizedBox(
                          width: MediaQuery.of(context).size.width,
                          height: 100,
                          child: const Center(
                              child: SizedBox(
                            width: 30,
                            height: 30,
                            child: CircularProgressIndicator(
                              color: Color(0xffFF4F4F),
                            ),
                          )),
                        );
                      },
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "Offers",
                  style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Bold',
                      color: Color(0xff202020)),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 250,
                margin: const EdgeInsets.only(top: 20, bottom: 20),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    FutureBuilder(
                      future: offers(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            itemCount: snapshot.data!.length,
                            shrinkWrap: true,
                            itemBuilder: (BuildContext context, index) {
                              return MiniCourse(
                                img: snapshot.data![index]['img'],
                                enroll: snapshot.data![index]['enroll'],
                                title: snapshot.data![index]['title'],
                                tag: snapshot.data![index]['tag'],
                                mrp: snapshot.data![index]['mrp'],
                                discount: snapshot.data![index]['discount'],
                              );
                            },
                          );
                        } else if (snapshot.hasError) {
                          return Container(
                            width: MediaQuery.of(context).size.width,
                            height: 100,
                            alignment: Alignment.center,
                            child: const Text(
                              "Something went wrong",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontFamily: 'Medium',
                                  color: Color(0xff202020)),
                            ),
                          );
                        }
                        // By default, show a loading spinner.
                        return SizedBox(
                          width: MediaQuery.of(context).size.width,
                          height: 100,
                          child: const Center(
                              child: SizedBox(
                            width: 30,
                            height: 30,
                            child: CircularProgressIndicator(
                              color: Color(0xffFF4F4F),
                            ),
                          )),
                        );
                      },
                    ),
                    const SizedBox(
                      width: 20,
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    )));
  }
}
