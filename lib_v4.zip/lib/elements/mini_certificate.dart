import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MiniCertificate extends StatefulWidget {
  String name;
  String tag;
  MiniCertificate({super.key, required this.name, required this.tag});

  @override
  State<MiniCertificate> createState() => _MiniCertificateState();
}

class _MiniCertificateState extends State<MiniCertificate> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: Column(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.70,
            height: 180,
            child: Image.asset(
              "assets/certificate.png",
              fit: BoxFit.fill,
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width * 0.70,
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              widget.name,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: const TextStyle(
                  fontSize: 15,
                  fontFamily: 'SemiBold',
                  color: Color(0xff202020)),
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width * 0.70,
            padding: const EdgeInsets.only(top: 8, bottom: 10),
            child: Text(
              widget.tag,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: const TextStyle(
                  fontSize: 13, fontFamily: 'Medium', color: Color(0xff767676)),
            ),
          ),
        ],
      ),
    );
  }
}
