import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MiniCourse extends StatefulWidget {
  String img;
  String enroll;
  String title;
  String tag;
  String mrp;
  String discount;
  MiniCourse(
      {super.key,
      required this.img,
      required this.enroll,
      required this.title,
      required this.tag,
      required this.mrp,
      required this.discount});

  @override
  State<MiniCourse> createState() => _MiniCourseState();
}

class _MiniCourseState extends State<MiniCourse> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    return Container(
      width: MediaQuery.of(context).size.width * 0.75,
      color: Colors.white,
      margin: const EdgeInsets.only(left: 20),
      child: Column(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.network(
            widget.img,
            width: MediaQuery.of(context).size.width * 0.75,
            height: 140,
            fit: BoxFit.fill,
          ),
        ),
        Container(
          margin: const EdgeInsets.only(top: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              const Icon(
                Icons.person_outline,
                size: 15,
                color: Color(0xff767676),
              ),
              Text(
                "${widget.enroll} Enrolled",
                style: const TextStyle(
                    fontSize: 10,
                    fontFamily: 'Medium',
                    color: Color(0xff767676)),
              ),
            ],
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.75,
          padding: const EdgeInsets.only(top: 5),
          child: Text(
            widget.title,
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
            style: const TextStyle(
                fontSize: 15, fontFamily: 'SemiBold', color: Color(0xff202020)),
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width * 0.75,
          padding: const EdgeInsets.only(top: 5, bottom: 5),
          child: Text(
            widget.tag,
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
            style: const TextStyle(
                fontSize: 13, fontFamily: 'Medium', color: Color(0xff767676)),
          ),
        ),
        Row(
          children: [
            const Text(
              "₹498",
              style: TextStyle(
                  fontSize: 15, fontFamily: 'Bold', color: Color(0xff202020)),
            ),
            const SizedBox(
              width: 5,
            ),
            Text(
              "\u{00A0}₹${widget.mrp}\u{00A0}",
              style: const TextStyle(
                  decoration: TextDecoration.lineThrough,
                  decorationColor: Color(0xff202020),
                  decorationThickness: 2,
                  fontSize: 13,
                  fontFamily: 'Medium',
                  color: Color(0xff202020)),
            ),
            const SizedBox(
              width: 5,
            ),
            Text(
              "${widget.discount}% OFF",
              style: const TextStyle(
                  fontSize: 13, fontFamily: 'Medium', color: Color(0xff00BB40)),
            )
          ],
        )
      ]),
    );
  }
}
