import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TitleBar extends StatefulWidget {
  const TitleBar({super.key});

  @override
  State<TitleBar> createState() => _TitleBarState();
}

class _TitleBarState extends State<TitleBar> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark));

    return Container(
      width: MediaQuery.of(context).size.width,
      height: 70,
      // color: Colors.green,
      alignment: Alignment.centerLeft,
      child: Padding(
        padding:
            EdgeInsets.only(left: MediaQuery.of(context).size.width * 0.05),
        child: const Text(
          "upScale",
          style: TextStyle(
              fontSize: 30, fontFamily: 'ExtraBold', color: Color(0xffFF4F4F)),
        ),
      ),
    );
  }
}
