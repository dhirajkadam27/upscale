import 'package:flutter/material.dart';
import 'bottom_navigation_screens/home.dart';

Future<void> main() async {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: 'Splash',
      routes: {
        'Splash': (context) => const Home(),
      },
    );
  }
}
