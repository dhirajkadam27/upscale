import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:upscale3/screens/home.dart';
import 'package:upscale3/screens/my_certificates.dart';
import 'package:upscale3/screens/profile.dart';

class BottomNavigation extends StatefulWidget {
  const BottomNavigation({super.key});

  @override
  State<BottomNavigation> createState() => _BottomNavigationState();
}

class _BottomNavigationState extends State<BottomNavigation> {
  final user = Hive.box('User');
  bool theme = false;
  int index = 0;
  final screens = const [Home(), MyCertificates(), Profile()];

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Stack(
      children: [
        screens[index],
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            color: theme ? Colors.black : Colors.white,
            padding: const EdgeInsets.only(top: 2, bottom: 2),
            child: BottomNavigationBar(
              elevation: 0, // to
              selectedItemColor: const Color(0xffFF4F4F),
              unselectedItemColor:
                  theme ? const Color(0xffFFFFFF) : const Color(0xff383838),
              unselectedLabelStyle:
                  const TextStyle(fontWeight: FontWeight.w400, fontSize: 10),
              selectedLabelStyle:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 10),
              selectedFontSize: 12,
              backgroundColor: Colors.white.withOpacity(0.0),
              type: BottomNavigationBarType.fixed,
              currentIndex: index,
              onTap: (index) => setState(() {
                this.index = index;
              }),
              items: const [
                BottomNavigationBarItem(
                    activeIcon: Padding(
                      padding: EdgeInsets.only(bottom: 2),
                      child: Icon(Icons.home_filled),
                    ),
                    icon: Padding(
                        padding: EdgeInsets.only(bottom: 2),
                        child: Icon(Icons.home_filled)),
                    label: "Home"),
                BottomNavigationBarItem(
                    activeIcon: Padding(
                        padding: EdgeInsets.only(bottom: 2),
                        child: Icon(Icons.local_library)),
                    icon: Padding(
                        padding: EdgeInsets.only(bottom: 2),
                        child: Icon(Icons.local_library_outlined)),
                    label: "My certificate"),
                BottomNavigationBarItem(
                    activeIcon: Padding(
                        padding: EdgeInsets.only(bottom: 2),
                        child: Icon(Icons.account_circle)),
                    icon: Padding(
                        padding: EdgeInsets.only(bottom: 2),
                        child: Icon(Icons.account_circle_outlined)),
                    label: "Profile"),
              ],
            ),
          ),
        ),
      ],
    )));
  }
}
