import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';
import 'package:shimmer/shimmer.dart';

class HomeCategories extends StatefulWidget {
  const HomeCategories({super.key});

  @override
  State<HomeCategories> createState() => _HomeCategoriesState();
}

class _HomeCategoriesState extends State<HomeCategories> {
  final user = Hive.box('User');
  bool theme = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future fetchCategories() async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/upscale/categories.php'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 10,
              height: 30,
              color: const Color(0xffFF4F4F),
            ),
            const SizedBox(
              width: 10,
            ),
            Text(
              "Categories",
              style: TextStyle(
                  fontSize: 20,
                  color: theme ? Colors.white : const Color(0xff212121),
                  fontFamily: 'Bold'),
            ),
          ],
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          height: 40,
          margin: const EdgeInsets.only(top: 20, bottom: 20),
          alignment: Alignment.center,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              FutureBuilder(
                future: fetchCategories(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: snapshot.data!.length,
                      shrinkWrap: true,
                      itemBuilder: (BuildContext context, index) {
                        return Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.only(left: 15),
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? const Color(0xff1F222A)
                                      : const Color(0xffE3E3E3)),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : Colors.white),
                          child: Text(
                            snapshot.data[index]['name'],
                            style: TextStyle(
                                fontSize: 15,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff7A7A7A),
                                fontFamily: 'Bold'),
                          ),
                        );
                      },
                    );
                  }

                  // By default, show a loading spinner.
                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 30,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.only(left: 15),
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? const Color(0xff1F222A)
                                      : const Color(0xffE3E3E3)),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : Colors.white),
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: 200,
                              height: 10,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.only(left: 15),
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? const Color(0xff1F222A)
                                      : const Color(0xffE3E3E3)),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : Colors.white),
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: 200,
                              height: 10,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(
                width: 20,
              )
            ],
          ),
        )
      ],
    );
  }
}
