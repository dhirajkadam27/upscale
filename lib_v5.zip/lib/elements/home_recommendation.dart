import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';
import 'package:shimmer/shimmer.dart';

class HomeRecommendations extends StatefulWidget {
  const HomeRecommendations({super.key});

  @override
  State<HomeRecommendations> createState() => _HomeRecommendationsState();
}

class _HomeRecommendationsState extends State<HomeRecommendations> {
  final user = Hive.box('User');
  bool theme = false;
  String tag = "All";
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future fetchRecommendedCategories() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/upscale/recommended_categories.php'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  Future fetchRecommended() async {
    try {
      final fetch = await http.get(
          Uri.parse('https://mydukanpe.com/upscale/recommended.php?tag=$tag'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 10,
              height: 30,
              color: const Color(0xffFF4F4F),
            ),
            const SizedBox(
              width: 10,
            ),
            Text(
              "Recommended for you",
              style: TextStyle(
                  fontSize: 20,
                  color: theme ? Colors.white : const Color(0xff212121),
                  fontFamily: 'Bold'),
            ),
          ],
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          height: 40,
          margin: const EdgeInsets.only(top: 20, bottom: 20),
          alignment: Alignment.center,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    tag = "All";
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.only(left: 15),
                  height: 30,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          width: 1,
                          color: theme
                              ? const Color(0xff1F222A)
                              : const Color(0xffE3E3E3)),
                      color: tag == "All"
                          ? const Color(0xffFF4F4F)
                          : theme
                              ? const Color(0xff1F222A)
                              : Colors.white),
                  child: Text(
                    "All",
                    style: TextStyle(
                        fontSize: 15,
                        color: tag == "All"
                            ? Colors.white
                            : theme
                                ? Colors.white
                                : const Color(0xff7A7A7A),
                        fontFamily: 'Bold'),
                  ),
                ),
              ),
              FutureBuilder(
                future: fetchRecommendedCategories(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: snapshot.data!.length,
                      shrinkWrap: true,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () {
                            setState(() {
                              tag = snapshot.data[index]['tag'];
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.only(left: 15),
                            height: 30,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    width: 1,
                                    color: theme
                                        ? const Color(0xff1F222A)
                                        : const Color(0xffE3E3E3)),
                                color: tag == snapshot.data[index]['tag']
                                    ? const Color(0xffFF4F4F)
                                    : theme
                                        ? const Color(0xff1F222A)
                                        : Colors.white),
                            child: Text(
                              snapshot.data[index]['tag'],
                              style: TextStyle(
                                  fontSize: 15,
                                  color: tag == snapshot.data[index]['tag']
                                      ? Colors.white
                                      : theme
                                          ? Colors.white
                                          : const Color(0xff7A7A7A),
                                  fontFamily: 'Bold'),
                            ),
                          ),
                        );
                      },
                    );
                  }

                  // By default, show a loading spinner.
                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 30,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.only(left: 15),
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? const Color(0xff1F222A)
                                      : const Color(0xffE3E3E3)),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : Colors.white),
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: 200,
                              height: 10,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.only(left: 15),
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? const Color(0xff1F222A)
                                      : const Color(0xffE3E3E3)),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : Colors.white),
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: 200,
                              height: 10,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(
                width: 20,
              )
            ],
          ),
        ),
        Column(
          children: [
            FutureBuilder(
              future: fetchRecommended(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    scrollDirection: Axis.vertical,
                    itemCount: snapshot.data!.length,
                    shrinkWrap: true,
                    itemBuilder: (BuildContext context, index) {
                      return Container(
                          width: MediaQuery.of(context).size.width * 0.90,
                          height: 320,
                          padding: const EdgeInsets.all(10),
                          margin: EdgeInsets.only(
                              bottom: 20,
                              left: MediaQuery.of(context).size.width * 0.05,
                              right: MediaQuery.of(context).size.width * 0.05),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? const Color(0xff1F222A)
                                      : const Color(0xffE3E3E3)),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : Colors.white),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(5),
                                child: Image.network(
                                  snapshot.data[index]['img'],
                                  width: (MediaQuery.of(context).size.width *
                                          0.90) -
                                      10,
                                  height: 170,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 10),
                                child: Text(
                                  snapshot.data[index]['title'],
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: TextStyle(
                                      fontSize: 18,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff212121),
                                      fontFamily: 'Bold'),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  snapshot.data[index]['tag'],
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff7A7A7A),
                                      fontFamily: 'SemiBold'),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  "${snapshot.data[index]['enroll']} Enrolled  |  ${snapshot.data[index]['language']}",
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff7A7A7A),
                                      fontFamily: 'SemiBold'),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        "₹${snapshot.data[index]['selling_price']}",
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: const TextStyle(
                                            fontSize: 25,
                                            color: Color(0xffFF4F4F),
                                            fontFamily: 'Bold'),
                                      ),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "\u{00A0}₹${snapshot.data[index]['mrp']}\u{00A0}",
                                        style: TextStyle(
                                            decoration:
                                                TextDecoration.lineThrough,
                                            decorationColor: theme
                                                ? Colors.white
                                                : const Color(0xff7A7A7A),
                                            decorationThickness: 2,
                                            fontSize: 18,
                                            color: theme
                                                ? Colors.white
                                                : const Color(0xff7A7A7A)),
                                      ),
                                    ],
                                  ),
                                  Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                        color: const Color(0xffFF4F4F),
                                        borderRadius: BorderRadius.circular(5)),
                                    child: const Text(
                                      "90% 0FF",
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontFamily: 'Bold',
                                          color: Colors.white),
                                    ),
                                  )
                                ],
                              )
                            ],
                          ));
                    },
                  );
                }

                // By default, show a loading spinner.
                return Container(
                    width: MediaQuery.of(context).size.width,
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Container(
                            width: MediaQuery.of(context).size.width * 0.90,
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.only(bottom: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    width: 1,
                                    color: theme
                                        ? const Color(0xff1F222A)
                                        : const Color(0xffE3E3E3)),
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : Colors.white),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(5),
                                    child: Shimmer.fromColors(
                                      baseColor: const Color(0xffEEEEEE),
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width:
                                            (MediaQuery.of(context).size.width *
                                                    0.90) -
                                                10,
                                        height: 120,
                                        color: Colors.black,
                                      ),
                                    )),
                                Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Shimmer.fromColors(
                                      baseColor: const Color(0xffEEEEEE),
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.80,
                                        height: 10,
                                        color: Colors.black,
                                      ),
                                    )),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Shimmer.fromColors(
                                    baseColor: const Color(0xffEEEEEE),
                                    highlightColor: Colors.white,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.40,
                                      height: 10,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Shimmer.fromColors(
                                    baseColor: const Color(0xffEEEEEE),
                                    highlightColor: Colors.white,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.30,
                                      height: 10,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Shimmer.fromColors(
                                          baseColor: const Color(0xffEEEEEE),
                                          highlightColor: Colors.white,
                                          child: Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                        const SizedBox(
                                          width: 5,
                                        ),
                                        Shimmer.fromColors(
                                          baseColor: const Color(0xffEEEEEE),
                                          highlightColor: Colors.white,
                                          child: Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      alignment: Alignment.centerLeft,
                                      child: Shimmer.fromColors(
                                        baseColor: const Color(0xffEEEEEE),
                                        highlightColor: Colors.white,
                                        child: Container(
                                          width: 50,
                                          height: 20,
                                          color: Colors.black,
                                        ),
                                      ),
                                    )
                                  ],
                                )
                              ],
                            )),
                        Container(
                            width: MediaQuery.of(context).size.width * 0.90,
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.only(bottom: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    width: 1,
                                    color: theme
                                        ? const Color(0xff1F222A)
                                        : const Color(0xffE3E3E3)),
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : Colors.white),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(5),
                                    child: Shimmer.fromColors(
                                      baseColor: const Color(0xffEEEEEE),
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width:
                                            (MediaQuery.of(context).size.width *
                                                    0.90) -
                                                10,
                                        height: 120,
                                        color: Colors.black,
                                      ),
                                    )),
                                Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Shimmer.fromColors(
                                      baseColor: const Color(0xffEEEEEE),
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.80,
                                        height: 10,
                                        color: Colors.black,
                                      ),
                                    )),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Shimmer.fromColors(
                                    baseColor: const Color(0xffEEEEEE),
                                    highlightColor: Colors.white,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.40,
                                      height: 10,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Shimmer.fromColors(
                                    baseColor: const Color(0xffEEEEEE),
                                    highlightColor: Colors.white,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.30,
                                      height: 10,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Shimmer.fromColors(
                                          baseColor: const Color(0xffEEEEEE),
                                          highlightColor: Colors.white,
                                          child: Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                        const SizedBox(
                                          width: 5,
                                        ),
                                        Shimmer.fromColors(
                                          baseColor: const Color(0xffEEEEEE),
                                          highlightColor: Colors.white,
                                          child: Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      alignment: Alignment.centerLeft,
                                      child: Shimmer.fromColors(
                                        baseColor: const Color(0xffEEEEEE),
                                        highlightColor: Colors.white,
                                        child: Container(
                                          width: 50,
                                          height: 20,
                                          color: Colors.black,
                                        ),
                                      ),
                                    )
                                  ],
                                )
                              ],
                            )),
                        Container(
                            width: MediaQuery.of(context).size.width * 0.90,
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.only(bottom: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    width: 1,
                                    color: theme
                                        ? const Color(0xff1F222A)
                                        : const Color(0xffE3E3E3)),
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : Colors.white),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(5),
                                    child: Shimmer.fromColors(
                                      baseColor: const Color(0xffEEEEEE),
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width:
                                            (MediaQuery.of(context).size.width *
                                                    0.90) -
                                                10,
                                        height: 120,
                                        color: Colors.black,
                                      ),
                                    )),
                                Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Shimmer.fromColors(
                                      baseColor: const Color(0xffEEEEEE),
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.80,
                                        height: 10,
                                        color: Colors.black,
                                      ),
                                    )),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Shimmer.fromColors(
                                    baseColor: const Color(0xffEEEEEE),
                                    highlightColor: Colors.white,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.40,
                                      height: 10,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Shimmer.fromColors(
                                    baseColor: const Color(0xffEEEEEE),
                                    highlightColor: Colors.white,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.30,
                                      height: 10,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Shimmer.fromColors(
                                          baseColor: const Color(0xffEEEEEE),
                                          highlightColor: Colors.white,
                                          child: Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                        const SizedBox(
                                          width: 5,
                                        ),
                                        Shimmer.fromColors(
                                          baseColor: const Color(0xffEEEEEE),
                                          highlightColor: Colors.white,
                                          child: Container(
                                            width: 50,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      alignment: Alignment.centerLeft,
                                      child: Shimmer.fromColors(
                                        baseColor: const Color(0xffEEEEEE),
                                        highlightColor: Colors.white,
                                        child: Container(
                                          width: 50,
                                          height: 20,
                                          color: Colors.black,
                                        ),
                                      ),
                                    )
                                  ],
                                )
                              ],
                            )),
                      ],
                    ));
              },
            ),
          ],
        ),
      ],
    );
  }
}
