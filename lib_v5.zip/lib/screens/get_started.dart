import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';
import 'package:upscale3/screens/name.dart';

class GetStarted extends StatefulWidget {
  const GetStarted({super.key});

  @override
  State<GetStarted> createState() => _GetStartedState();
}

class _GetStartedState extends State<GetStarted> {
  final user = Hive.box('User');
  bool theme = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xffFF4F4F),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        backgroundColor: const Color(0xffFF4F4F),
        body: Column(
          children: [
            const SizedBox(
              height: 80,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 100,
              alignment: Alignment.center,
              child: Text(
                "upScale",
                style: TextStyle(
                    fontSize: 40,
                    color: theme ? const Color(0xff212121) : Colors.white,
                    fontFamily: 'Black'),
              ),
            ),
            const SizedBox(
              height: 100,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding:
                    EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
                child: Text(
                  "Start your \ncareer Journey\nhere.....",
                  style: TextStyle(
                      fontSize: 35,
                      color: theme ? const Color(0xff212121) : Colors.white,
                      fontFamily: 'ExtraBold'),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Container(
              alignment: Alignment.center,
              width: MediaQuery.of(context).size.width,
              child: InkWell(
                onTap: () {
                  FirebaseAuth.instance
                      .authStateChanges()
                      .listen((User? user) async {
                    if (user == null) {
                      print('User is currently signed out!');
                    } else {
                      await GoogleSignIn().disconnect();
                      FirebaseAuth.instance.signOut();
                    }
                  });
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => const Name()));
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.90,
                  height: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: theme ? const Color(0xff212121) : Colors.white),
                  alignment: Alignment.center,
                  child: Text(
                    "Get Started",
                    style: TextStyle(
                        fontSize: 18,
                        color: theme ? Colors.white : const Color(0xff212121),
                        fontFamily: 'Bold'),
                  ),
                ),
              ),
            )
          ],
        ));
  }
}
