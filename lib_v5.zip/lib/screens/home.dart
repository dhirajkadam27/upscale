import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hive/hive.dart';
import 'package:upscale3/elements/home_recommendation.dart';
import 'package:upscale3/elements/home_top_certificated.dart';

import '/elements/home_categories.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final user = Hive.box('User');
  bool theme = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        backgroundColor: theme ? const Color(0xff181A20) : Colors.white,
        body: SafeArea(
          child: ListView(
            children: [
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: const Text(
                  "upScale",
                  style: TextStyle(
                      fontSize: 35,
                      color: Color(0xffFF4F4F),
                      fontFamily: 'Black'),
                ),
              ),
              InkWell(
                onTap: () {
                  _showSearch(context);
                },
                child: Container(
                  margin: EdgeInsets.only(
                      top: 20,
                      left: MediaQuery.of(context).size.width * 0.05,
                      right: MediaQuery.of(context).size.width * 0.05),
                  width: MediaQuery.of(context).size.width * 0.90,
                  height: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: theme
                          ? const Color(0xff1F222A)
                          : const Color(0xffEEEEEE)),
                  child: Row(
                    children: [
                      const SizedBox(
                        width: 10,
                      ),
                      Icon(
                        Icons.search_outlined,
                        size: 25,
                        color: theme ? Colors.white : const Color(0xff9D9D9D),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Search your query",
                        style: TextStyle(
                            fontSize: 17,
                            color:
                                theme ? Colors.white : const Color(0xff9D9D9D),
                            fontFamily: 'Bold'),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 10,
                      height: 30,
                      color: const Color(0xffFF4F4F),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Special Offers",
                      style: TextStyle(
                          fontSize: 20,
                          color: theme ? Colors.white : const Color(0xff212121),
                          fontFamily: 'Bold'),
                    ),
                  ],
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                alignment: Alignment.center,
                margin: const EdgeInsets.only(top: 20, bottom: 20),
                child: SvgPicture.asset('assets/banner.svg'),
              ),
              const HomeCategories(),
              const HomeTopCertificates(),
              const HomeRecommendations()
            ],
          ),
        ));
  }

  _showSearch(context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Material(
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              color: theme ? const Color(0xff181A20) : Colors.white,
              child: ListView(
                children: [
                  const SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.keyboard_arrow_left_outlined,
                          size: 35,
                          color: theme ? Colors.white : const Color(0xff7A7A7A),
                        ),
                      ),
                      Container(
                          width: MediaQuery.of(context).size.width * 0.80,
                          height: 45,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : const Color(0xffEEEEEE)),
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: TextField(
                            style: TextStyle(
                                fontSize: 17,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff7A7A7A),
                                fontFamily: 'Bold'),
                            decoration: InputDecoration(
                                hintStyle: TextStyle(
                                    fontSize: 17,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    fontFamily: 'Bold'),
                                border: InputBorder.none,
                                hintText: 'Enter Your Name',
                                fillColor: theme
                                    ? Colors.white
                                    : const Color(0xff7A7A7A)),
                          )),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }
}
