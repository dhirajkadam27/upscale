import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_highlighter/flutter_highlighter.dart';
import 'package:flutter_highlighter/themes/solarized-dark.dart';
import 'package:flutter_highlighter/themes/solarized-light.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';

class MCQ extends StatefulWidget {
  const MCQ({super.key});

  @override
  State<MCQ> createState() => _MCQState();
}

class _MCQState extends State<MCQ> {
  final user = Hive.box('User');
  bool theme = false;
  int active = 0;
  int total = 0;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future fetchMCQ() async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/upscale/mcq.php?id=1'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        total = response.length;
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    var code = '''i = 1
while True:
    if i%3 == 0:
        break
    print(i)
 
    i + = 1

    i = 1
while True:
    if i%3 == 0:
        break
    print(i)
 
    i + = 1

''';
    return Scaffold(
        backgroundColor: theme ? const Color(0xff181A20) : Colors.white,
        body: SafeArea(
          child: ListView(
            children: [
              Padding(
                padding: EdgeInsets.only(
                    top: 10,
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: const [
                        Icon(
                          Icons.keyboard_arrow_left,
                          size: 25,
                          color: Color(0xff0075FF),
                        ),
                        Text(
                          "back",
                          style: TextStyle(
                              fontSize: 15,
                              color: Color(0xff0075FF),
                              fontFamily: 'Semibold'),
                        )
                      ],
                    ),
                    Text(
                      "30:00",
                      style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Black',
                          color:
                              theme ? Colors.white : const Color(0xff212121)),
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: const Color(0xffFF4F4F),
                          borderRadius: BorderRadius.circular(5)),
                      child: const Text(
                        "Submit",
                        style: TextStyle(
                            fontSize: 13,
                            fontFamily: 'Bold',
                            color: Colors.white),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 50,
                margin: const EdgeInsets.only(top: 30),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    FutureBuilder(
                      future: fetchMCQ(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            itemCount: snapshot.data!.length,
                            shrinkWrap: true,
                            itemBuilder: (BuildContext context, index) {
                              return InkWell(
                                onTap: () {
                                  setState(() {
                                    active = index;
                                  });
                                },
                                child: Container(
                                  margin: const EdgeInsets.only(left: 20),
                                  alignment: Alignment.center,
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        color: active == index
                                            ? const Color(0xffFF4F4F)
                                            : const Color(0xffEEEEEE)),
                                    child: Center(
                                        child: Text(
                                      index.toString(),
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontFamily: 'SemiBold',
                                          color: active == index
                                              ? Colors.white
                                              : const Color(0xff212121)),
                                    )),
                                  ),
                                ),
                              );
                            },
                          );
                        }

                        // By default, show a loading spinner.
                        return SizedBox(
                          width: MediaQuery.of(context).size.width,
                          height: 40,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                margin: const EdgeInsets.only(left: 15),
                                height: 40,
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : Colors.white,
                                child: Shimmer.fromColors(
                                  baseColor: const Color(0xffEEEEEE),
                                  highlightColor: Colors.white,
                                  child: Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                        color: Colors.black,
                                        borderRadius:
                                            BorderRadius.circular(100)),
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.all(10),
                                margin: const EdgeInsets.only(left: 15),
                                height: 40,
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : Colors.white,
                                child: Shimmer.fromColors(
                                  baseColor: const Color(0xffEEEEEE),
                                  highlightColor: Colors.white,
                                  child: Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                        color: Colors.black,
                                        borderRadius:
                                            BorderRadius.circular(100)),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    const SizedBox(
                      width: 20,
                    )
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: 30,
                    bottom: 30,
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05),
                child: FutureBuilder(
                  future: fetchMCQ(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Text(
                        snapshot.data[active]['que'],
                        style: TextStyle(
                            fontSize: 18,
                            fontFamily: 'SemiBold',
                            color:
                                theme ? Colors.white : const Color(0xff212121)),
                      );
                    } else if (snapshot.hasError) {
                      return Text('${snapshot.error}');
                    }

                    // By default, show a loading spinner.
                    return Shimmer.fromColors(
                      baseColor: const Color(0xffEEEEEE),
                      highlightColor: Colors.white,
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        height: 20,
                        color: Colors.black,
                      ),
                    );
                  },
                ),
              ),
              FutureBuilder(
                future: fetchMCQ(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data[active]['code'] != "") {
                      return Container(
                        alignment: Alignment.center,
                        margin: const EdgeInsets.only(bottom: 20),
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.80,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: theme
                                  ? const Color(0xff1F222A)
                                  : const Color(0xffEEEEEE)),
                          child: HighlightView(
                            // The original code to be highlighted
                            snapshot.data[active]['code'],

                            // Specify language
                            // It is recommended to give it a value for performance
                            language: 'dart',

                            // Specify highlight theme
                            // All available themes are listed in `themes` folder
                            theme: theme
                                ? solarizedDarkTheme
                                : solarizedLightTheme,

                            // Specify padding
                            padding: const EdgeInsets.all(10),

                            // Specify text style
                            textStyle: const TextStyle(
                              fontFamily: 'Medium',
                              fontSize: 16,
                            ),
                          ),
                        ),
                      );
                    } else {
                      return const Text("");
                    }
                  } else if (snapshot.hasError) {
                    return Text('${snapshot.error}');
                  }

                  // By default, show a loading spinner.
                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 100,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.only(left: 15),
                          height: 100,
                          color: theme ? const Color(0xff1F222A) : Colors.white,
                          child: Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.80,
                              height: 100,
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
              Column(
                children: [
                  Container(
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(top: 10),
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: theme
                              ? const Color(0xff1F222A)
                              : const Color(0xffEEEEEE)),
                      padding: const EdgeInsets.all(15),
                      child: FutureBuilder(
                        future: fetchMCQ(),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.85,
                              child: Text(
                                snapshot.data[active]['a'],
                                style: TextStyle(
                                    fontSize: 18,
                                    fontFamily: 'SemiBold',
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff212121)),
                              ),
                            );
                          } else if (snapshot.hasError) {
                            return Text('${snapshot.error}');
                          }

                          // By default, show a loading spinner.
                          return Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 20,
                              color: Colors.black,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(top: 10),
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: theme
                              ? const Color(0xff1F222A)
                              : const Color(0xffEEEEEE)),
                      padding: const EdgeInsets.all(15),
                      child: FutureBuilder(
                        future: fetchMCQ(),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.85,
                              child: Text(
                                snapshot.data[active]['b'],
                                style: TextStyle(
                                    fontSize: 18,
                                    fontFamily: 'SemiBold',
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff212121)),
                              ),
                            );
                          } else if (snapshot.hasError) {
                            return Text('${snapshot.error}');
                          }

                          // By default, show a loading spinner.
                          return Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 20,
                              color: Colors.black,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(top: 10),
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: theme
                              ? const Color(0xff1F222A)
                              : const Color(0xffEEEEEE)),
                      padding: const EdgeInsets.all(15),
                      child: FutureBuilder(
                        future: fetchMCQ(),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.85,
                              child: Text(
                                snapshot.data[active]['c'],
                                style: TextStyle(
                                    fontSize: 18,
                                    fontFamily: 'SemiBold',
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff212121)),
                              ),
                            );
                          } else if (snapshot.hasError) {
                            return Text('${snapshot.error}');
                          }

                          // By default, show a loading spinner.
                          return Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 20,
                              color: Colors.black,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(top: 10),
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: theme
                              ? const Color(0xff1F222A)
                              : const Color(0xffEEEEEE)),
                      padding: const EdgeInsets.all(15),
                      child: FutureBuilder(
                        future: fetchMCQ(),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.85,
                              child: Text(
                                snapshot.data[active]['d'],
                                style: TextStyle(
                                    fontSize: 18,
                                    fontFamily: 'SemiBold',
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff212121)),
                              ),
                            );
                          } else if (snapshot.hasError) {
                            return Text('${snapshot.error}');
                          }

                          // By default, show a loading spinner.
                          return Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              height: 20,
                              color: Colors.black,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30, bottom: 30),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        if (active > 0) {
                          setState(() {
                            active--;
                          });
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                            color: const Color(0xffFF4F4F),
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          children: const [
                            Icon(
                              Icons.keyboard_arrow_left_outlined,
                              size: 25,
                              color: Colors.white,
                            ),
                            Text(
                              "Prev",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontFamily: 'Bold',
                                  color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        if (active < total - 1) {
                          setState(() {
                            active++;
                          });
                        }
                      },
                      child: Container(
                        margin: const EdgeInsets.only(left: 10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            color: const Color(0xffFF4F4F),
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          children: const [
                            Text(
                              "Next",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontFamily: 'Bold',
                                  color: Colors.white),
                            ),
                            Icon(
                              Icons.keyboard_arrow_right_outlined,
                              size: 25,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ));
  }
}
