import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';

class MyCertificates extends StatefulWidget {
  const MyCertificates({super.key});

  @override
  State<MyCertificates> createState() => _MyCertificatesState();
}

class _MyCertificatesState extends State<MyCertificates> {
  final user = Hive.box('User');
  bool theme = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        backgroundColor: theme ? const Color(0xff181A20) : Colors.white,
        body: SafeArea(
          child: ListView(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 10,
                      height: 30,
                      color: const Color(0xffFF4F4F),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      "My Certificates",
                      style: TextStyle(
                          fontSize: 20,
                          color: theme ? Colors.white : const Color(0xff212121),
                          fontFamily: 'Bold'),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Column(
                  children: [
                    Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        height: 320,
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.only(bottom: 20),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                width: 1,
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : const Color(0xffE3E3E3)),
                            color:
                                theme ? const Color(0xff1F222A) : Colors.white),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(5),
                              child: Image.network(
                                "https://trainings.internshala.com/cached_uploads/homepage/media/courses_section/card_images/web-development.png",
                                width:
                                    (MediaQuery.of(context).size.width * 0.90) -
                                        10,
                                height: 170,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                "Programming With Python",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 18,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff212121),
                                    fontFamily: 'Bold'),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                "Web Development",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    fontFamily: 'SemiBold'),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                "1000 Enrolled  |  Hindi",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 10,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    fontFamily: 'SemiBold'),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: const Color(0xffFF4F4F),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: const Text(
                                    "Share",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontFamily: 'Bold',
                                        color: Colors.white),
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: const Color(0xffFF4F4F),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: const Text(
                                    "View Certificate",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontFamily: 'Bold',
                                        color: Colors.white),
                                  ),
                                )
                              ],
                            )
                          ],
                        )),
                    Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        height: 320,
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.only(bottom: 20),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                width: 1,
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : const Color(0xffE3E3E3)),
                            color:
                                theme ? const Color(0xff1F222A) : Colors.white),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(5),
                              child: Image.network(
                                "https://trainings.internshala.com/cached_uploads/homepage/media/courses_section/card_images/web-development.png",
                                width:
                                    (MediaQuery.of(context).size.width * 0.90) -
                                        10,
                                height: 170,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                "Programming With Python",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 18,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff212121),
                                    fontFamily: 'Bold'),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                "Web Development",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    fontFamily: 'SemiBold'),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                "1000 Enrolled  |  Hindi",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 10,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    fontFamily: 'SemiBold'),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: const Color(0xffFF4F4F),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: const Text(
                                    "Share",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontFamily: 'Bold',
                                        color: Colors.white),
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: const Color(0xffFF4F4F),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: const Text(
                                    "Complete",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontFamily: 'Bold',
                                        color: Colors.white),
                                  ),
                                )
                              ],
                            )
                          ],
                        )),
                    Container(
                        width: MediaQuery.of(context).size.width * 0.90,
                        height: 320,
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.only(bottom: 20),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                width: 1,
                                color: theme
                                    ? const Color(0xff1F222A)
                                    : const Color(0xffE3E3E3)),
                            color:
                                theme ? const Color(0xff1F222A) : Colors.white),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(5),
                              child: Image.network(
                                "https://trainings.internshala.com/cached_uploads/homepage/media/courses_section/card_images/web-development.png",
                                width:
                                    (MediaQuery.of(context).size.width * 0.90) -
                                        10,
                                height: 170,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                "Programming With Python",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 18,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff212121),
                                    fontFamily: 'Bold'),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                "Web Development",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    fontFamily: 'SemiBold'),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                "1000 Enrolled  |  Hindi",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 10,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    fontFamily: 'SemiBold'),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: const Color(0xffFF4F4F),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: const Text(
                                    "Share",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontFamily: 'Bold',
                                        color: Colors.white),
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: const Color(0xffFF4F4F),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: const Text(
                                    "Complete",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontFamily: 'Bold',
                                        color: Colors.white),
                                  ),
                                )
                              ],
                            )
                          ],
                        )),
                  ],
                ),
              )
            ],
          ),
        ));
  }
}
