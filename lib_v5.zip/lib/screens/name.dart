import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';
import 'package:upscale3/bottom_navigation.dart';

class Name extends StatefulWidget {
  const Name({super.key});

  @override
  State<Name> createState() => _NameState();
}

class _NameState extends State<Name> {
  TextEditingController nameController = TextEditingController();
  final user = Hive.box('User');
  bool loader = true;
  bool theme = false;
  @override
  void initState() {
    super.initState();
    googleLogin();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  googleLogin() async {
    print("googleLogin method Called");
    GoogleSignIn _googleSignIn = GoogleSignIn();
    try {
      var reslut = await _googleSignIn.signIn();
      if (reslut == null) {
        return;
      }

      final userData = await reslut.authentication;
      final credential = GoogleAuthProvider.credential(
          accessToken: userData.accessToken, idToken: userData.idToken);
      var finalResult =
          await FirebaseAuth.instance.signInWithCredential(credential);
      setState(() {
        // google_sign_completed = true;
        // email = reslut.email;R
        // photo = reslut.photoUrl!;
        loader = false;
        nameController.text = reslut.displayName!;
      });
      if (reslut.displayName == null) {
        // showerror(context, "Something went wrong");
      }
    } catch (error) {
      // showerror(context, "Something went wrong");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        backgroundColor: theme ? const Color(0xff181A20) : Colors.white,
        body: Stack(
          children: [
            Padding(
              padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 80,
                  ),
                  Text(
                    "What’s your name?",
                    style: TextStyle(
                        fontSize: 28,
                        color: theme ? Colors.white : const Color(0xff212121),
                        fontFamily: 'Black'),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: theme
                              ? const Color(0xff1F222A)
                              : const Color(0xffEEEEEE)),
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: TextField(
                        controller: nameController,
                        style: TextStyle(
                            fontSize: 17,
                            color:
                                theme ? Colors.white : const Color(0xff212121),
                            fontFamily: 'Bold'),
                        decoration: InputDecoration(
                            hintStyle: TextStyle(
                                fontSize: 17,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff212121),
                                fontFamily: 'Bold'),
                            border: InputBorder.none,
                            hintText: 'Enter Your Name',
                            fillColor:
                                theme ? Colors.white : const Color(0xff7A7A7A)),
                      )),
                  const SizedBox(
                    height: 30,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              const BottomNavigation()));
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: const Color(0xffFF4F4F)),
                      alignment: Alignment.center,
                      child: Text(
                        "Continue",
                        style: TextStyle(
                            fontSize: 18,
                            color: theme ? Colors.black : Colors.white,
                            fontFamily: 'Bold'),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            loader
                ? Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: theme
                        ? const Color(0xff181A20).withOpacity(0.3)
                        : Colors.white.withOpacity(0.3),
                    child: const Center(
                        child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xffFF4F4F),
                      ),
                    )),
                  )
                : const Text(""),
          ],
        ));
  }
}
