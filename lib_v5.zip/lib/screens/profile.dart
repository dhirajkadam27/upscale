import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final user = Hive.box('User');
  bool theme = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        backgroundColor: theme ? const Color(0xff181A20) : Colors.white,
        body: SafeArea(
          child: ListView(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30, bottom: 30),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 10,
                      height: 30,
                      color: const Color(0xffFF4F4F),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Profile",
                      style: TextStyle(
                          fontSize: 20,
                          color: theme ? Colors.white : const Color(0xff212121),
                          fontFamily: 'Bold'),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.05,
                  ),
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: const Color(0xffD9D9D9)),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Dhiraj Kadam",
                        style: TextStyle(
                            fontSize: 15,
                            color:
                                theme ? Colors.white : const Color(0xff212121),
                            fontFamily: 'Bold'),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        "DhirajKadam@gmail.com",
                        style: TextStyle(
                            fontSize: 15,
                            color:
                                theme ? Colors.white : const Color(0xff7A7A7A),
                            fontFamily: 'SemiBold'),
                      )
                    ],
                  )
                ],
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.80,
                height: 1,
                color: const Color(0xffE3E3E3),
                margin: EdgeInsets.only(
                    top: 30,
                    bottom: 10,
                    left: MediaQuery.of(context).size.width * 0.10,
                    right: MediaQuery.of(context).size.width * 0.10),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.05,
                        ),
                        const Icon(
                          Icons.nightlight_round,
                          size: 25,
                          color: Color(0xff7A7A7A),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text("Dark Mode",
                            style: TextStyle(
                                fontSize: 15,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff7A7A7A),
                                fontFamily: 'SemiBold')),
                      ],
                    ),
                    Switch(
                      // thumb color (round icon)
                      activeColor: Color(0xff3491FF),
                      activeTrackColor: Color.fromARGB(255, 163, 204, 255),
                      inactiveThumbColor: Color.fromARGB(255, 255, 255, 255),
                      inactiveTrackColor: Color.fromARGB(255, 136, 136, 136),
                      splashRadius: 50.0,
                      // boolean variable value
                      value: theme,
                      // changes the state of the switch
                      onChanged: (value) {
                        if (value) {
                          user.put("theme", "dark");
                        } else {
                          user.put("theme", "light");
                        }
                        setState(() {
                          theme = value;
                        });
                      },
                    ),
                    const SizedBox(
                      width: 40,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 10),
                child: Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.05,
                    ),
                    const Icon(
                      Icons.mode_edit_outline,
                      size: 25,
                      color: Color(0xff7A7A7A),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text("Profile Edit",
                        style: TextStyle(
                            fontSize: 15,
                            color:
                                theme ? Colors.white : const Color(0xff7A7A7A),
                            fontFamily: 'SemiBold'))
                  ],
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.80,
                height: 1,
                color: const Color(0xffE3E3E3),
                margin: EdgeInsets.only(
                    top: 10,
                    bottom: 10,
                    left: MediaQuery.of(context).size.width * 0.10,
                    right: MediaQuery.of(context).size.width * 0.10),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 10),
                child: Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.05,
                    ),
                    const Icon(
                      Icons.link,
                      size: 25,
                      color: Color(0xff7A7A7A),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text("Privacy Policy",
                        style: TextStyle(
                            fontSize: 15,
                            color:
                                theme ? Colors.white : const Color(0xff7A7A7A),
                            fontFamily: 'SemiBold'))
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 10),
                child: Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.05,
                    ),
                    const Icon(
                      Icons.link,
                      size: 25,
                      color: Color(0xff7A7A7A),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text("Terms",
                        style: TextStyle(
                            fontSize: 15,
                            color:
                                theme ? Colors.white : const Color(0xff7A7A7A),
                            fontFamily: 'SemiBold'))
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 10),
                child: Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.05,
                    ),
                    const Icon(
                      Icons.logout,
                      size: 25,
                      color: Color(0xff7A7A7A),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text("Logout",
                        style: TextStyle(
                            fontSize: 15,
                            color:
                                theme ? Colors.white : const Color(0xff7A7A7A),
                            fontFamily: 'SemiBold'))
                  ],
                ),
              )
            ],
          ),
        ));
  }
}
