import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hive/hive.dart';
import 'package:shimmer/shimmer.dart';
import 'package:upscale3/screens/mcq.dart';
import 'package:http/http.dart' as http;

import 'home.dart';

class ViewMore extends StatefulWidget {
  const ViewMore({super.key});

  @override
  State<ViewMore> createState() => _ViewMoreState();
}

class _ViewMoreState extends State<ViewMore> {
  final user = Hive.box('User');
  bool theme = false;
  String img = "";
  String title = "";
  String tag = "";
  String enroll = "";
  String language = "";
  String sellingprice = "";
  String mrp = "";
  String mcq = "";
  @override
  void initState() {
    super.initState();
    fetchTopCertificates();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future fetchTopCertificates() async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/upscale/course.php?id=1'));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        setState(() {
          img = response[0]['img'];
          title = response[0]['title'];
          tag = response[0]['tag'];
          enroll = response[0]['enroll'];
          language = response[0]['language'];
          sellingprice = response[0]['selling_price'];
          mrp = response[0]['mrp'];
          mcq = response[0]['mcq'];
        });
        return response;
      } else {}
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff181A20) : Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        backgroundColor: theme ? const Color(0xff181A20) : Colors.white,
        body: SafeArea(
          child: Stack(
            children: [
              ListView(
                children: [
                  Stack(
                    children: [
                      img.isEmpty
                          ? Shimmer.fromColors(
                              baseColor: const Color(0xffEEEEEE),
                              highlightColor: Colors.white,
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                height: 170,
                                color: Colors.black,
                              ),
                            )
                          : Image.network(
                              img,
                              width: MediaQuery.of(context).size.width,
                              height: 170,
                              fit: BoxFit.cover,
                            ),
                      Positioned(
                        top: 15,
                        left: 10,
                        child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Container(
                            padding: const EdgeInsets.only(
                                left: 5, right: 15, top: 2, bottom: 2),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: const Color(0xffFF4F4F)),
                            child: Row(
                              children: const [
                                Icon(
                                  Icons.keyboard_arrow_left,
                                  size: 25,
                                  color: Colors.white,
                                ),
                                Text(
                                  "back",
                                  style: TextStyle(
                                      fontSize: 15,
                                      color: Colors.white,
                                      fontFamily: 'Semibold'),
                                )
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: 20,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: title.isEmpty
                        ? Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              height: 10,
                              color: Colors.black,
                            ),
                          )
                        : Text(
                            title,
                            style: TextStyle(
                                fontSize: 20,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff212121),
                                fontFamily: 'Bold'),
                          ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: 8,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: tag.isEmpty
                        ? Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              alignment: Alignment.centerLeft,
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.40,
                                height: 10,
                                color: Colors.black,
                              ),
                            ),
                          )
                        : Text(
                            tag,
                            style: TextStyle(
                                fontSize: 13,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff7A7A7A),
                                fontFamily: 'SemiBold'),
                          ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: 8,
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: enroll.isEmpty
                        ? Shimmer.fromColors(
                            baseColor: const Color(0xffEEEEEE),
                            highlightColor: Colors.white,
                            child: Container(
                              alignment: Alignment.centerLeft,
                              child: Container(
                                width: MediaQuery.of(context).size.width * 0.30,
                                height: 10,
                                color: Colors.black,
                              ),
                            ),
                          )
                        : Text(
                            "$enroll Enrolled  |  $language",
                            style: TextStyle(
                                fontSize: 10,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff7A7A7A),
                                fontFamily: 'SemiBold'),
                          ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.05,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        sellingprice.isEmpty
                            ? Shimmer.fromColors(
                                baseColor: const Color(0xffEEEEEE),
                                highlightColor: Colors.white,
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    width: 100,
                                    height: 30,
                                    color: Colors.black,
                                  ),
                                ),
                              )
                            : Text(
                                "₹$sellingprice",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: const TextStyle(
                                    fontSize: 25,
                                    color: Color(0xffFF4F4F),
                                    fontFamily: 'Bold'),
                              ),
                        const SizedBox(
                          width: 10,
                        ),
                        mrp.isEmpty
                            ? Shimmer.fromColors(
                                baseColor: const Color(0xffEEEEEE),
                                highlightColor: Colors.white,
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    width: 100,
                                    height: 30,
                                    color: Colors.black,
                                  ),
                                ),
                              )
                            : Text(
                                "\u{00A0}₹$mrp\u{00A0}",
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    decorationColor: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A),
                                    decorationThickness: 2,
                                    fontSize: 18,
                                    color: theme
                                        ? Colors.white
                                        : const Color(0xff7A7A7A)),
                              ),
                        const SizedBox(
                          width: 10,
                        ),
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                              color: const Color(0xffFF4F4F),
                              borderRadius: BorderRadius.circular(5)),
                          child: const Text(
                            "90% 0FF",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: 'Bold',
                                color: Colors.white),
                          ),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: 30,
                        left: MediaQuery.of(context).size.width * 0.10,
                        right: MediaQuery.of(context).size.width * 0.05),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color(0xffFF4F4F)),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            mcq.isEmpty
                                ? Shimmer.fromColors(
                                    baseColor: const Color(0xffEEEEEE),
                                    highlightColor: Colors.white,
                                    child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        width: 200,
                                        height: 20,
                                        color: Colors.black,
                                      ),
                                    ),
                                  )
                                : Text(
                                    "$mcq MCQ based on theory",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: theme
                                            ? Colors.white
                                            : const Color(0xff7A7A7A),
                                        fontFamily: 'SemiBold'),
                                  )
                          ],
                        ),
                        Stack(
                          children: [
                            Container(
                              margin: const EdgeInsets.only(left: 8.5),
                              width: 3,
                              height: 40,
                              color: const Color(0xffD9D9D9),
                            ),
                            Container(
                              margin: const EdgeInsets.only(left: 8.5),
                              width: 3,
                              height: 20,
                              color: const Color(0xffFF4F4F),
                            )
                          ],
                        ),
                        Row(
                          children: [
                            Container(
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color(0xffD9D9D9)),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              "Certificate",
                              style: TextStyle(
                                  fontSize: 15,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff7A7A7A),
                                  fontFamily: 'SemiBold'),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    alignment: Alignment.centerLeft,
                    padding: EdgeInsets.only(
                      top: 30,
                      left: MediaQuery.of(context).size.width * 0.05,
                    ),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: const Color(0xffFF4F4F)),
                      child: const Text(
                        "Try a sample test",
                        style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                            fontFamily: 'Bold'),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 30),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: 10,
                          height: 30,
                          color: const Color(0xffFF4F4F),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Certificate Sample",
                          style: TextStyle(
                              fontSize: 20,
                              color: theme
                                  ? Colors.white
                                  : const Color(0xff212121),
                              fontFamily: 'Bold'),
                        ),
                      ],
                    ),
                  ),
                  SvgPicture.asset(
                    'assets/certificate.svg',
                    width: 300,
                  ),
                  const SizedBox(
                    height: 100,
                  ),
                ],
              ),
              Positioned(
                bottom: 20,
                left: MediaQuery.of(context).size.width * 0.05,
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => const MCQ()));
                  },
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: const Color(0xffFF4F4F)),
                    alignment: Alignment.center,
                    child: Text(
                      "Buy only at ₹$sellingprice",
                      style: TextStyle(
                          fontSize: 18,
                          color: theme ? Colors.black : Colors.white,
                          fontFamily: 'Bold'),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}
